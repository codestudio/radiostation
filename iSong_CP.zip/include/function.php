<?php
/************************************************************************************
RadioStation - Control Panel | v.1.0 | Worrawat Watakit (CODESTUDIO Network Enterprises) 
RadioStation Control Panel © 2017 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
if(!$ISONG){die("Access denied!");}
require("time.php");
require_once("class.xml.php");
function random_password($len)
{
	srand((double)microtime()*10000000);
	$chars = time()*rand(0,999) . "ABmyduC1EFGHKadcIJKLfnvcMNjOPQRcfcSTaUWXYcZ01va23456789";
	$ret_str = "";
	$num = strlen($chars);
	for($i = 0; $i < $len; $i++)
	{
	$ret_str.= $chars[rand()%$num];
	$ret_str.="";
	}
	return $ret_str;
}
function view_size($sizefile)
{ 
	if (!is_numeric($sizefile)) { 
	return FALSE; 
	} else { 
	if($sizefile >= 1099511627776) {$sizefile = round($sizefile/1099511627776*100)/100 ." TB";} 
	elseif ($sizefile >= 1073741824) {$sizefile = round($sizefile/1073741824*100)/100 ." GB";} 
	elseif ($sizefile >= 1048576) {$sizefile = round($sizefile/1048576*100)/100 ." MB";} 
	elseif ($sizefile >= 1024) {$sizefile = round($sizefile/1024*100)/100 ." KB";} 
	else {$sizefile = $sizefile . " B";} 
	return $sizefile; 
	}
}
function view_size_format($sizefile)
{ 
	if (!is_numeric($sizefile)) { 
	return FALSE; 
	} else { 
	if($sizefile >= 1099511627776) { $sizefile="TB"; }
	elseif ($sizefile >= 1073741824) {$sizefile = "GB";} 
	elseif ($sizefile >= 1048576) {$sizefile = "MB";} 
	elseif ($sizefile >= 1024) {$sizefile = "KB";} 
	else {$sizefile = "B";} 
	return $sizefile; 
	}
}

function view_size_conv($sizefile, $type) {
	if($type=="TB") {	$size = ($sizefile*1099511627776); } // 1 TB 
	elseif($type=="GB") {	$size = ($sizefile*1073741824); }  // 1 GB
	elseif($type=="MB") {	$size = ($sizefile*1048576); } // 1 MB
	elseif($type=="B") { $size = $sizefile; } // 1 B
	return $size;
}

function view_size_only($sizefile)
{ 
	if (!is_numeric($sizefile)) { 
	return FALSE; 
	} else { 
	if ($sizefile >= 1099511627776) {$sizefile = round($sizefile/1099511627776*100)/100;}  
	elseif ($sizefile >= 1073741824) {$sizefile = round($sizefile/1073741824*100)/100;}
	elseif ($sizefile >= 1048576) {$sizefile = round($sizefile/1048576*100)/100;}  //MB
	elseif ($sizefile >= 1024) {$sizefile = round($sizefile/1024*100)/100;}  //KB
	else {$sizefile = $sizefile;}  //B
	return $sizefile; 
	}
}
function ReadDirs($path,&$files = array())
{
    $dir = opendir($path."/.");
    while($item = readdir($dir))
        if(is_file($sub = $path."/".$item))
            $files[] = $item;else
            if($item != "." and $item != "..")
                files($sub,$files); 
    return($files);
}
function ReadDirsSize($path,&$files = array())
{
    $dir = opendir($path."/.");
    while($item = readdir($dir))
        if(is_file($sub = $path."/".$item))
            $filesize=($filesize+filesize($path.$item)); else
            if($item != "." and $item != "..")
                files($sub,$files); 
    return($filesize);
}
function memUsedSize(){
	$Control = new iSong_Control();
	$sc = $Control->mem("shoutcast");
	$tr = $Control->mem("transcoder");
	return ($sc+$tr*1024);
}

function cURL($url) {
	$isRequestHeader = FALSE;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}
function getOS() {
	if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
		return "win";
	} else {
		return "linux";
	}
}
class iSong_Config {
	public function __construct() {
		$this->fileXML = "include/config.xml";
		$this->configXML = file_get_contents($this->fileXML);
		$this->phpXML = new PhpJsonXmlArrayStringInterchanger();
		$this->Setting = $this->phpXML->convertXmltoArray($this->configXML);
	}
	public function ConfigSetting() {
		$array= $this->Setting;
		return $array;
	}
	public function ConfigUpdate($section,$setting,$replacement) {
		unset($xml);
		$xml = $this->phpXML->convertXmltoArray(file_get_contents($this->fileXML));
		$section_array = $xml[$section];
		foreach($section_array as $key=>$value) {
			if($key==$setting) {
				$xml[$section][$key] = $replacement;
			}
		}
		$newXML = $this->phpXML->convertArrayToXML($xml);
		return file_put_contents($this->fileXML,$newXML);
		
	}
	public function ConfigUpdateMuti($section,$array) {
		unset($xml,$newXML);
		$xml = $this->phpXML->convertXmltoArray(file_get_contents($this->fileXML));
		$section_array = $xml[$section];
		foreach($array as $aKey=>$aValue) {
			foreach($section_array as $key=>$value) {
				if($key==$aKey) {
					$xml[$section][$aKey] = $aValue;
				}
			}
		}
		$xmlContent = $this->phpXML->convertArrayToXML($xml);
		$fh = fopen($this->fileXML, 'w') or die("Can't open file");
		fwrite($fh, $xmlContent);
		fclose($fh);	
	}
	public function ConfigUpdateArray($section,$replacement) {
		$xml = $this->ConfigSetting();
		$xml[$section] = $replacement;
		$newXML = $this->phpXML->convertArrayToXML($xml);
		file_put_contents($this->fileXML,$newXML);
	}
	public function Setting($section, $name) {
		$output = $this->Setting[$section][$name];
		return $output;
	}
	public function Configuration($config,$name) {
		$output = $this->Setting["configuration"][$config][$name];
		return $output;
	}
}
function PageMSG($msg,$result,$returnURL=NULL) {
	if($result){ $Msg=$msg; $returnURL=$returnURL; include("pages/page.success.php"); exit(); }
	else { $Msg=$msg;  include("pages/page.error.php"); exit(); }
}
class iSong_Auth {
	public function __construct() {
		$this->Config = new iSong_Config(); 
		$this->ConfigSetting = $this->Config->ConfigSetting();
	}
	public function Signin($password) {
		if($this->CheckPassword(md5($password))) { 
			$this->Auth($password);
			return true; 
		}
		return false;
	}
	public function doLogout() {
		session_destroy();
	}
	public function SavePassword($passwordNew) {
		$this->Config->ConfigUpdate("auth","password",md5($passwordNew));
		$this->Signin($passwordNew);
		$_SESSION["auth_isong"]=md5($passwordNew);
		return true;
	}
	public function isAuth() {
		if($this->CheckPassword($_SESSION["auth_isong"])) {
			return true;
		}
		return false;
	}
	private function CheckPassword($password) {
		$password = trim($password);
		if($password==$this->ConfigSetting['auth']['password']) { return true; }
		return false;
	}
	private function Auth($password) {
		$_SESSION["auth_isong"]=md5($password);
		$this->Config->ConfigUpdate("auth","last_login",date("d-m-Y [H:i:s]"));
		$this->Config->ConfigUpdate("auth","last_ip",$_SERVER['REMOTE_ADDR']);
	}
}
class iSong_Configuration {
	public function __construct() {
		$this->Config = new iSong_Config(); 
		$this->ConfigSetting = $this->Config->ConfigSetting();
		$this->PathBackend = $this->ConfigSetting['system']['path_backend'];
		$this->PathLibs = $this->ConfigSetting['system']['path_libs'];
		$this->PathConfig = $this->ConfigSetting['system']['path_config'];
		$this->PathLogs = $this->PathBackend."logs/";
	}
	public function Shoutcast() {
		$config = $this->ConfigSetting['configuration']['shoutcast'];
		$replace = array("%password%","%adminpassword%","%portbase%","%path_logs%","%maxuser%","%titleformat%","%urlformat%","%publicserver%","%autodumpsourcetime%","%songhistory%","%cpucount%","%streampath%","%log%");
		$output = array($config['password'],$config['adminpassword'],$config['portbase'],$this->PathLogs,$config['maxuser'],$config['titleformat'],$config['urlformat'],$config['publicserver'],$config['autodumpsourcetime'],$config['songhistory'],$config['cpucount'],$config['streampath'],$config['log']);
		$this->Generated("shoutcast",$replace,$output);
	}
	public function Transcoder() {
		$config = $this->ConfigSetting['configuration']['transcoder'];
		$playlistfile = $this->PathBackend."playlist.lst";
		$replace = array("%outprotocol%","%serverip%","%serverport%","%password%","%streamid%","%endpointname%","%adminport%","%adminpassword%","%bitrate%","%samplerate%","%channels%","%mp3quality%","%mp3mode%",
							"%genre%","%streamtitle%","%streamurl%","%shuffle%","%xfade%","%path_logs%","%playlistfile%","%log%");
		$output = array($config['outprotocol'],$config['serverip'],$config['serverport'],$config['password'],$config['streamid'],$config['endpointname'],$config['adminport'],$config['adminpass'],$config['bitrate'],$config['samplerate'],$config['channels'],$config['mp3quality'],$config['mp3mode'],
							$config['genre'],$config['streamtitle'],$config['streamurl'],$config['shuffle'],$config['xfade'],$this->PathLogs,$playlistfile,$config['log']);
		$this->Generated("transcoder",$replace,$output);
	}
	private function Generated($template,$replace,$output) {
		$template_path = $this->PathConfig."template.".$template.".txt";
		$config_path = $this->ConfigSetting['system']['config_'.$template];
		$template_file = file_get_contents($template_path);
		$config_generated = str_replace($replace,$output,$template_file);
		file_put_contents($config_path, $config_generated);
	}
}

class iSong_Playlist {
	public function __construct() {
		$this->Config = new iSong_Config(); 
		$this->ConfigSetting = $this->Config->ConfigSetting();
		$this->PathMusic = $this->ConfigSetting['system']['path_music'];
		$this->PathBackend = $this->ConfigSetting['system']['path_backend'];
	}
	public function Generated() {
		$Read = ReadDirs($this->PathMusic);
		foreach($Read as $file_name) {
			$list .= $this->PathMusic.$file_name."\r\n";
		}
		$this->Build($list);
	}
	private function Build($content) {
		$playlist_file = $this->PathBackend."playlist.lst";
		file_put_contents($playlist_file,$content);
	}
}
class iSong_Control {
	public function __construct() {
		$this->Config = new iSong_Config(); 
		$this->ConfigSetting = $this->Config->ConfigSetting();
		$this->OS = getOS();
		$this->pidSHOUTCast = $this->PathBackend."shoutcast.pid";
		$this->pidTranscoder = $this->PathBackend."transcoder.pid";
		$this->PathBackend = $this->ConfigSetting['system']['path_backend'];
	}
	public function Control_SHOUTcast() {
		return $this->toggleProcess("shoutcast");
	}
	public function Control_Transcoder() {
		return $this->toggleProcess("transcoder");
	}
	
	private function toggleProcess($type) {
		$pid_process=$this->pidProccess($type);
		if($pid_process==0) {
			return $this->StartProcess($type);
		} else {
			if($this->CheckProcess($type)) {
				return $this->StopProcess($type);
			} else {
				return $this->StartProcess($type);
			}
		}
	}
	public function CheckProcess($type) {
		if($this->pidProccess($type)=="0") { return false; }
		if($this->OS=="win"){ return $this->winCheckPID($this->pidProccess($type),$type); }
		if($this->OS=="linux"){ return $this->linuxCheckPID($this->pidProccess($type),$type); }
	}
	public function CheckStatus($type) {
		$type_port = ($type=="shoutcast")? "portbase" : "adminport";
		return $this->Socket("127.0.0.1",$this->Config->Configuration[$type][$type_port]);	
	}
	public function StartProcess($type) {
		if($type=="shoutcast") {
			if($this->OS=="win") { $pid = $this->winStartProcess($this->ConfigSetting['system']['path_win']."sc_serv.exe", $this->ConfigSetting['system']['config_shoutcast']);  }
			else { $pid = $this->linuxStartProcess($this->ConfigSetting['system']['path_linux']."sc_serv", $this->ConfigSetting['system']['config_shoutcast']);  }
			if($pid!=0) { $this->pidSave("shoutcast",$pid); return true; } else { $this->pidSave("shoutcast",0); return false; }
		} else if($type=="transcoder") {
			if($this->OS=="win") { $pid = $this->winStartProcess($this->ConfigSetting['system']['path_win']."sc_trans.exe", $this->ConfigSetting['system']['config_transcoder']);  }
			else { $pid = $this->linuxStartProcess($this->ConfigSetting['system']['path_linux']."sc_trans", $this->ConfigSetting['system']['config_transcoder']);  }
			if($pid!=0) { $this->pidSave("transcoder",$pid); return true; } else { $this->pidSave("transcoder",0); return false; }
		}
		return false;
	}
	public function StopProcess($type) {
		if($this->OS=="win"){ $this->winStopProcess($this->pidProccess($type)); $this->pidSave($type,"0"); }
		if($this->OS=="linux"){ $this->linuxStopProcess($this->pidProccess($type)); $this->pidSave($type,"0"); }
		return true;
	}
	public function mem($type) {
		if($this->OS=="win"){ return $this->winMem($this->pidProccess($type)); }
		if($this->OS=="linux"){ return "0"; }
	}
	private function winStartProcess($runPath, $configfile) {
		$pstools = $this->ConfigSetting['system']['path_pstools'];
		$runPath = str_replace('\\','/',$runPath);
		$command = $pstools."psexec.exe -e -d -i 0 -accepteula \"".$runPath."\" ".$configfile." 2>&1";
		echo $command;
		exec($command,$out);

		preg_match('/ID (\d+)/', $out[6], $matches);
		$pid = $matches[1];
		return ($pid ? $pid:0);
	}
	private function linuxStartProcess($runPath, $configfile) {
		$root = $this->ConfigSetting['system']['path_linux']; 
		$runPath = str_replace('\\','/',$runPath);
		$cmdstr = "".$runPath." ".$configfile." </dev/null 2>/dev/null >/dev/null & echo $!";
		$pid = shell_exec($cmdstr);
		return $pid;
	}
	private function winStopProcess($pid) {
		exec($this->ConfigSetting['system']['path_pstools']."pskill.exe -accepteula ".$pid,$out);
		return $out;
	}
	private function linuxStopProcess($pid) {
		shell_exec("kill ".$pid);
		return true;
	}
	private function winCheckPID($pid,$type) {
		$exec = ($type=="shoutcast")?"sc_serv":"sc_trans";
		exec($this->ConfigSetting['system']['path_pstools']."pslist.exe -accepteula ".$pid,$out);
		return (strpos($out[3],$exec) !== false ? true:false);
	}
	private function linuxCheckPID($pid,$type) {
		$exec = ($type=="shoutcast")?"sc_serv":"sc_trans";
		$output = shell_exec('ps -p '.$pid); 
		return (strpos($output,$exec)!==false ? true:false);
	}
	private function winMem($pid) {
		exec('tasklist /FI "pid eq '.$pid.'" /FO CSV 2>&1',$out);
		$out = str_replace('"',"",$out[1]);
		$exout = explode(",",$out);
		return $exout[4].$exout[5];
	}
	public function pidProccess($type) {
		$pid=file_get_contents($this->PathBackend.$type.".pid");
		return trim($pid);
	}
	private function pidSave($type,$pid) {
		$pid = trim($pid);
		$putcontent=file_put_contents($this->PathBackend.$type.".pid",$pid);
		return true;
	}
	private function Socket($ip,$port) {
		$connection = @fsockopen($ip, $port, $errno, $errstr, 1);
		return $connection;
	}
}
class iSong_SHOUTcast {
	public function __construct() {
		$this->Config = new iSong_Config(); 
		$this->ConfigSetting = $this->Config->ConfigSetting();
	}
	public function sc_stats() {
		$get = "http://".$this->ConfigSetting["system"]["ip"].":".$this->ConfigSetting["configuration"]["shoutcast"]["portbase"]."/stats?sid=1";
		$this->phpXML = new PhpJsonXmlArrayStringInterchanger();
		$array = $this->phpXML->convertXmltoArray(cURL($get));
		$new = @array_change_key_case ($array,CASE_LOWER);
		return $new;
	}
	public function iTunes($songtitle) {
		$term = urlencode($songtitle);
		$json =  file_get_contents('http://itunes.apple.com/search?term='.$term.'&limit=1&media=music');    
		$array = json_decode($json, true);
		if($array['resultCount']==0) { return false; }
		$array = $array['results']['0'];
		return $array;
	}
	public function weblet($command) {
		if($command=="restart") {
			$Control = new iSong_Control();
			$Control->StopProcess("shoutcast");
			sleep(1);
			$Control->StartProcess("shoutcast");
			return true;
		}
		if($command=="reload") {
			$get = file_get_contents("http://admin:".$this->ConfigSetting['configuration']['shoutcast']['adminpassword']."@127.0.0.1:".$this->ConfigSetting['configuration']['shoutcast']['portbase']."/admin.cgi?mode=reload&force=1");
			return true;
		}
		if($command=="kicksrc"){
			$get = file_get_contents("http://admin:".$this->ConfigSetting['configuration']['shoutcast']['adminpassword']."@127.0.0.1:".$this->ConfigSetting['configuration']['shoutcast']['portbase']."/admin.cgi?sid=1&mode=kicksrc");
			return true;
		}
	}
}
class iSong_Transcoder {
	public function __construct() {
		$this->Config = new iSong_Config(); 
		$this->ConfigSetting = $this->Config->ConfigSetting();
	}
	public function weblet($command) {
		if($command=="restart") {
			$Control = new iSong_Control();
			$Control->StopProcess("transcoder");
			sleep(1);
			$Control->StartProcess("transcoder");
			return true;
		}
		if($command!="restart") {
			if(@file_get_contents("http://admin:".$this->ConfigSetting['configuration']['transcoder']['adminpass']."@127.0.0.1:".$this->ConfigSetting['configuration']['transcoder']['adminport']."/".$command) == "<html><body>OK</body></html>")
			{ sleep(1); return true; }else{ return false; }
		}
	}
	
}
class iSong_Station {
	public function __construct() {
		$this->Config = new iSong_Config(); 
		$this->ConfigSetting = $this->Config->ConfigSetting();
		$this->PathBackend = $this->ConfigSetting['system']['path_backend'];
		$this->PathStyle = $this->PathBackend."/station/style/";
		$this->phpXML =new PhpJsonXmlArrayStringInterchanger();
		$this->CommentXML = $this->PathBackend."/station/comments.xml";
	}
	public function loadSetting($PlayerID) {
		$targetFolder = $this->PathStyle.$PlayerID.".xml";
		if(!file_exists($targetFolder)) { return false; }
		$Setting = $this->phpXML->convertXmltoArray(file_get_contents($targetFolder));
		return $Setting;
	}
	public function listComment() {
		return $this->phpXML->convertXmltoArray(file_get_contents($this->CommentXML));
	}
	public function CommentUpdate($id,$field,$replace) {
		/*$oldComment = $this->phpXML->convertXmltoArray(file_get_contents($this->CommentXML));
		$idComment = $oldComment[$id];
		foreach($idComment as $key=>$value) {
			if($key==$field) {
				$idComment[$field] = $replace;
			}
		}
		$oldComment[$id] = $idComment;
		$xml = $this->phpXML->convertArrayToXML($oldComment);
		@file_put_contents($this->CommentXML,$xml);
		return true;*/
	}
	public function deleteAllComments() {
		$newComment = array("comment_1"=>array("name"=>"System","comment"=>"Delete all comments.","ip"=>"0","read"=>"yes","time"=>time()));
		$xml = $this->phpXML->convertArrayToXML($newComment);
		@file_put_contents($this->CommentXML,$xml);
		$this->Config->ConfigUpdate("station","comment_count","1");
		return true;
	}
	public function deleteComment($idDel) {
		$Comment = $this->phpXML->convertXmltoArray(file_get_contents($this->CommentXML));
		foreach($Comment as $key=>$value) {
			if($key==$idDel) { unset($Comment[$key]); }
		}
		$xml = $this->phpXML->convertArrayToXML($Comment);
		@file_put_contents($this->CommentXML,$xml);
		return true;
	}
	public function Comment($name,$comment) {
		$oldComment = $this->phpXML->convertXmltoArray(file_get_contents($this->CommentXML));
		$count = "comment_".($this->ConfigSetting['station']['comment_count']+1);
		$_SESSION["comment_time"] = time();
		$newComment = array($count=>array(
			"name"=>$name,
			"comment"=>$comment,
			"ip"=>$_SERVER['REMOTE_ADDR'],
			"read"=>"yes",
			"time"=>time()
			)
		);
		$newArray = array_merge($oldComment,$newComment);
		$xml = $this->phpXML->convertArrayToXML($newArray);
		@file_put_contents($this->CommentXML,$xml);
		$this->Config->ConfigUpdate("station","comment_count",($this->ConfigSetting['station']['comment_count']+1));
		return true;
	}
	public function GeneratedPlayer($Array) {
		$xml=$this->phpXML->convertArrayToXML($Array);
		$randID = random_password(6);
		$filename = $randID.".xml";
		@file_put_contents($this->PathStyle.$filename,$xml);
		return $randID;
	}
}

?>