<?
require_once('getid3/getid3.php');
require_once('text.php');
// Initialize getID3 engine
$TaggingFormat = 'UTF-8';
$getID3 = new getID3;
$getID3->setOption(array('encoding'=>$TaggingFormat));

getid3_lib::IncludeDependency(GETID3_INCLUDEPATH.'write.php', __FILE__, true);

// Function
function write_tag($Filename, $title, $artist) {	
	global $TaggingFormat;
	@chmod($Filename, 0777);
	$tagwriter = new getid3_writetags;
	$tagwriter->filename       = $Filename;
	$tagwriter->tagformats     = array('id3v1','id3v2.3');
	$tagwriter->overwrite_tags = true;
	$tagwriter->tag_encoding   = "UTF-8";
	$tagwriter->remove_other_tags = true;

	$commonkeysarray = array('Title', 'Artist', 'Album', 'Year', 'Comment');
	foreach ($commonkeysarray as $key) {
		if (!empty($_POST[$key])) {
			$TagData[strtolower($key)][] = $_POST[$key];
		}
	}
	$TagData['title'][] = $title;
	$TagData['artist'][] = $artist;
	
	$tagwriter->tag_data = $TagData;
	if ($tagwriter->WriteTags()) {
		return true;
		if (!empty($tagwriter->warnings)) {
			return false;
		}
	} else {
		return false;
	}
	
}

function read_tag($Filename) {
	// Initialize getID3 engine
	chmod($Filename, 0777);
	$getID3 = new getID3;
	$OldThisFileInfo = $getID3->analyze($Filename);
	getid3_lib::CopyTagsToComments($OldThisFileInfo);
	$output=array("title"=>correct_encoding($OldThisFileInfo['id3v2']['comments']['title']['0']), "artist"=>correct_encoding($OldThisFileInfo['id3v2']['comments']['artist']['0']));

	return $output;

}
?>