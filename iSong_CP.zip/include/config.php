<?php
/************************************************************************************
RadioStation - Control Panel | v.1.0 | Worrawat Watakit (CODESTUDIO Network Enterprises) 
RadioStation Control Panel © 2017 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
if(!$ISONG){die("Access denied!");}
ob_start();
session_start();
require_once("function.php"); 

$CONFIG = new iSong_Config();
?>