<?
require_once("text.encoding.php");

$__tis620 = range(0xa1, 0xff);
$__tis620[] = 0xa0;
array_walk($__tis620, "to_char");

$__utf8 = range(0xe01, 0xe5f);
$__utf8[] = 0xa0;
array_walk($__utf8, "to_unicode");
function correct_encoding($text) {
    $current_encoding = mb_detect_encoding($text);
    $text = iconv($current_encoding, 'UTF-8//IGNORE', $text);
	//$newtext = iconv("UTF-8//IGNORE", "TIS-620", $text);
    return $text;
}

function tis620_utf8($str) {
    global $__tis620, $__utf8;
    if (function_exists("array_combine")) {
        $str = strtr($str, array_combine($__tis620, $__utf8));
    } else {
        $str = strtr($str, _array_combine($__tis620, $__utf8));
    }
    return $str;
}

function utf8_tis620($str) {
    global $__tis620, $__utf8;
    if (function_exists("array_combine")) {
        $str = strtr($str, array_combine($__utf8, $__tis620));
    } else {
        $str = strtr($str, _array_combine($__utf8, $__tis620));
    }
    return $str;
}

function to_char(&$item, $key) {
    $item = chr($item);
}

function to_unicode(&$item, $key) {
    $item = codepoint_utf8($item);
}

function codepoint_utf8($codepoint) {
    $ascii = "";
    if ($codepoint < 0x80) {
        $ascii .= chr($codepoint);
    } elseif ($codepoint < 0x800) {
        $ascii .= chr(0xc0 | ($codepoint >> 6));
        $ascii .= chr(0x80 | ($codepoint & 0x3f));
    } elseif ($codepoint < 0x10000) {
        $ascii .= chr(0xe0 | ($codepoint >> 12));
        $ascii .= chr(0x80 | ($codepoint >> 6 ) & 0x3f);
        $ascii .= chr(0x80 | ($codepoint & 0x3f));
    } else {
        $ascii .= chr(0xf0 | ($codepoint >> 18));
        $ascii .= chr(0x80 | ($codepoint >> 12 ) & 0x3f);
        $ascii .= chr(0x80 | ($codepoint >> 6 ) & 0x3f);
        $ascii .= chr(0x80 | ($codepoint & 0x3f));
    }
    return $ascii;
}

function _array_combine($k, $v) {
    $output = array();
    for ($i = 0; $i < count($k); $i++) {
        $output[$k[$i]] = $v[$i];
    }
    return $output;
}

?>