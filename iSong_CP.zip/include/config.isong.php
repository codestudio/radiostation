<?
require("class.xml.php");
$array = array(
	"auth"=>array(
		"password"=>"21232f297a57a5a743894a0e4a801fc3",
		"last_login"=>"0",
		"last_ip"=>"127.0.0.1",
		"name"=>"Demo",
	),
	"site"=>array(
		"title"=>"iSong Control Panel",
		"short_title"=>"iSong CP",
		"baseurl"=>"http://localhost/iSong_CP/",
		"installed"=>"false",
	),
	"station"=>array(
		"title"=>"iSong.in.TH",
		"cover"=>"http://www.isong.in.th/images/cover.jpg",
		"comment_count"=>"1",
	),
	"system"=>array(
		"path_root"=>"E:/www/iSong_CP/",
		"path_backend"=>"E:/www/iSong_CP/backend/",
		"path_music"=>"E:/www/iSong_CP/backend/music/",
		"path_music_url"=>"http://localhost/iSong_CP/backend/music/",
		"path_libs"=>"E:/www/iSong_CP/libs/",
		"path_config"=>"E:/www/iSong_CP/libs/configuration/",
		"path_win"=>"E:/www/iSong_CP/libs/win/",
		"path_linux"=>"E:/www/iSong_CP/libs/linux/",
		"path_pstools"=>"E:/www/iSong_CP/libs/win/pstools/",
		"config_shoutcast"=>"E:/www/iSong_CP/libs/configuration/sc_isong.conf",
		"config_transcoder"=>"E:/www/iSong_CP/libs/configuration/tr_isong.conf",
		"ip"=>"127.0.0.1",
	),
	"configuration"=>array(
	"shoutcast"=>array(
		"password"=>"pass",
		"adminpassword"=>"adminpass",
		"portbase"=>"8000",
		"maxuser"=>"100",
		"publicserver"=>"never",
		"songhistory"=>"10",
		"titleformat"=>"iSong Control Panel @ %s ",
		"urlformat"=>"http://www.isong.in.th/",
		"cpucount"=>"2",
		"autodumpsourcetime"=>"30",
		"streampath"=>"/iSong",
		"streamurl"=>"http://www.isong.in.th/",
		"log"=>"1",
	),
	"transcoder"=>array(
		"remote_host"=>"local",
		"outprotocol"=>"3",
		"serverip"=>"127.0.0.1",
		"password"=>"pass",
		"serverport"=>"8000",
		"public"=>"0",
		"adminport"=>"8002",
		"adminpass"=>"adminpass",
		"streamid"=>"1",
		"endpointname"=>"/iSong",
		"streamtitle"=>"AutoDJ",
		"streamurl"=>"http://www.isong.in.th/",
		"genre"=>"iSong",
		"bitrate"=>"128000",
		"mp3quality"=>"0",
		"mp3mode"=>"0",
		"channels"=>"2",
		"shuffle"=>"1",
		"samplerate"=>"44100",
		"xfade"=>"3",
		"log"=>"1",
	),
	)
);

$object=new PhpJsonXmlArrayStringInterchanger();
$xml=$object->convertArrayToXML($array);
if($xml===false){
	//$object->displayErrorLog();
	$object->displayLastError();
}
else{
	//header("content-type: text/xml");
	file_put_contents("config.xml",$xml);
	exit;
}


?>