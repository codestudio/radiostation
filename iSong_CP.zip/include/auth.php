<?
if(!$ISONG){die("Access denied!");}
$Auth = new iSong_Auth();
if(!$Auth->isAuth()) {
	header("Location: index.php?return=".$_SERVER['REQUEST_URI']);
}
?>