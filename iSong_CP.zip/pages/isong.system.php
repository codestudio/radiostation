<?
/************************************************************************************
iSong - Control Panel by Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
?>
<div class="form-title" style="margin-top:0px;">Account  <small>บัญชีผู้ใช้งาน</small> <div class="pull-right"><a onClick="toggleShow('form-account');" class="cursor-pointer">Show/Hide</a></div> </div>
<? if($_SESSION["msg_ok"]!=""){?><div class="alert alert-success"><i class="fa fa-check"></i> <?=$_SESSION["msg_ok"]?></div><? $_SESSION["msg_ok"]="";}?>
<form class="form-horizontal form-panel" id="form-account" role="form-password" action="index.php?do=save" method="post">
    <dl class="dl-horizontal">
      <dt>Accout name</dt><dd><?=$CONFIG->Setting('auth','name')?></dd>
      <dt>Last login</dt><dd><?=$CONFIG->Setting('auth','last_login')?> <small>(IP: <?=$CONFIG->Setting('auth','last_ip')?>)</small></dd>
    </dl>
  <div class="form-group">
    <label for="password" class="col-sm-3 control-label">Password</label>
    <div class="col-sm-9">
      <input type="password" class="form-control" id="password" placeholder="Password" name="password">
    </div>
  </div>
  <div class="form-group">
    <label for="repassword" class="col-sm-3 control-label">Re-Password</label>
    <div class="col-sm-9">
      <input type="password" class="form-control" id="repassword" placeholder="Re-Password" name="repassword">
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-success"><i class="fa fa-check"></i> Save</button>
    </div>
  </div>
</form>
<hr>
<div class="form-title" style="margin-top:0px;">Configuration <small>ข้อมูลทั่วไป</small> <div class="pull-right"><a onClick="toggleShow('form-site');" class="cursor-pointer">Show/Hide</a></div> </div>
<form class="form-horizontal form-panel" id="form-site" action="dashboard.php?section=system" method="post" onSubmit="loader('show');">
  <div class="form-group">
    <label for="site_title" class="col-sm-3 control-label">Site Title</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="site_title" name="site_title" value="<?=$CONFIG->Setting("site","title")?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="site_baseurl" class="col-sm-3 control-label">Baseurl</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="site_baseurl" name="site_baseurl" value="<?=$CONFIG->Setting("site","baseurl")?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="station_title" class="col-sm-3 control-label">Station title</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="station_title" name="station_title" value="<?=$CONFIG->Setting("station","title")?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="station_cover" class="col-sm-3 control-label">Station Cover</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="station_cover" name="station_cover" value="<?=$CONFIG->Setting("station","cover")?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="system_path_root" class="col-sm-3 control-label">Base directory</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="system_path_root" name="system_path_root" value="<?=$CONFIG->Setting("system","path_root")?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="system_ip" class="col-sm-3 control-label">ServerIP</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-4" id="system_ip" name="system_ip" value="<?=$CONFIG->Setting("system","ip")?>" required>
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-success"><i class="fa fa-check"></i> Save</button>
    </div>
  </div>
</form>
<style>
.section h4 { font-size:20px; }
.form-panel { padding:10px; border:1px solid #EAEAEA; border-radius:6px; }
.form-title {font-family:supermarket; font-size:26px; font-weight:bold; margin-top:30px;  }
.form-title .pull-right { font-size:13px; color:#000; line-height:30px;}
.form-title small { font-size:12px; }
.help-block { margin-top:-2px; font-size:10px; }
.btn-group { display:inline; }
</style>