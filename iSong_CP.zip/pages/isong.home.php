<?
/************************************************************************************
iSong - Control Panel by Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
$ConfigGenerated = new iSong_Configuration(); // First homepage
$ConfigGenerated->Shoutcast(); // Generated config file
$ConfigGenerated->Transcoder(); // Generated config file
?>
<div class="row ">
	<div class="col-lg-6">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title text-center ">SHOUTcast</h3>
          </div>
          <div class="panel-body">
            <div class="panel-status-btn"><a class="btn btn-block btn-lg btn-success isong-shoutcast-btn" data-status="" data-loading-text="Loading...">&nbsp;</a></div>
            <div class="panel-status text-green isong-shoutcast-text"></div>
          </div>
        </div>
    </div>
	<div class="col-lg-6">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title text-center">Transcoders</h3>
          </div>
          <div class="panel-body">
            <div class="panel-status-btn"><a class="btn btn-block btn-lg btn-success isong-transcoder-btn" data-status="" data-loading-text="Loading...">&nbsp;</a></div>
            <div class="panel-status text-red isong-transcoder-text"></div>
          </div>
        </div>
    </div>
</div>
<div class="row fontsupermarket">
	<div class="col-lg-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title text-center">จำนวนผู้ฟัง</h3>
          </div>
          <div class="panel-body">
          	<div class="dashbaord-text"><b class="isong-currentlisteners"></b> <span>/<?=$CONFIG->Configuration('shoutcast','maxuser')?></span></div>
          </div>
        </div>
    </div>
	<div class="col-lg-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title text-center">พื้นที่เก็บเพลง</h3>
          </div>
          <div class="panel-body"><? $dirSize=ReadDirsSize($CONFIG->Setting("system","path_music")); if($dirSize==""){$dirSize=0;} ?>
          	<div class="dashbaord-text"><?=view_size_only($dirSize); ?> <span><?=view_size_format($dirSize); ?></span></div>
          </div>
        </div>
    </div>
	<div class="col-lg-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title text-center">ใช้หน่วยความจำ</h3>
          </div>
          <div class="panel-body"><? $memSize = memUsedSize(); ?>
          	<div class="dashbaord-text"><?=view_size_only($memSize); ?> <span><?=view_size_format($memSize); ?></span></div>
          </div>
        </div>
    </div>
</div>

<div class="isong-shoutcast-stats">
</div>
<script>
$(document).ready(function(e) {
	iniStatus();
 	$(".isong-shoutcast-btn").live("click","",function(e){
		$(".isong-shoutcast-btn").button('loading');
		controlToggle("shoutcast");
	});
 	$(".isong-transcoder-btn").live("click","",function(e){
		$(".isong-transcoder-btn").button('loading');
		controlToggle("transcoder");
	});
	$(".isong-shoutcast-btn").live("mouseenter",function(e){ if($(this).attr("data-status")=="online") { $(this).html("Stop"); } if($(this).attr("data-status")=="offline") { $(this).html("Start"); } });
	$(".isong-shoutcast-btn").live("mouseleave",function(e){ if($(this).attr("data-status")=="online") { $(this).html("Online"); } if($(this).attr("data-status")=="offline") { $(this).html("Offline"); } });
	$(".isong-transcoder-btn").live("mouseenter",function(e){ if($(this).attr("data-status")=="online") { $(this).html("Stop"); } if($(this).attr("data-status")=="offline") { $(this).html("Start"); } });
	$(".isong-transcoder-btn").live("mouseleave",function(e){ if($(this).attr("data-status")=="online") { $(this).html("Online"); } if($(this).attr("data-status")=="offline") { $(this).html("Offline"); } });
});
</script>
