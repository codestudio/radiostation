<?php  header("Refresh: 5; url=".$returnURL."");?>
<html lang="th">
<head>
<meta charset="utf-8">
<title>iSong Control Panel</title>
<link rel="stylesheet" href="dist/css/bootstrap.css">
<link rel="stylesheet" href="dist/css/style.css">
</head>

<body>
<div class="PanelMain" style="max-width:400px; margin-top:60px;">
	<h2 class="PanelMain-heading">การทำรายการสำเร็จ</h2>
    <div class="alert alert-success"><?=$Msg?></div>
    <div class="text-center">
    	<a class="btn btn-success" href="<?=$returnURL?>"><i class="fa fa-check"></i> ตกลง</a> 
    </div>
</div>
</body>
</html>