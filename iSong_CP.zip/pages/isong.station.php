<?
/************************************************************************************
iSong - Control Panel by Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
$STATION = new iSong_Station();
?>
<div class="row"> <input type="hidden" id="show-panel" value="comments">
    <div class="btn-group fontsupermarket" data-toggle="buttons" style="width:99%; margin:5px;">
        <a class="btn btn-select btn-primary active" onClick="togglePanel()" id="comments-btn"><i class="fa fa-comments"></i> Comments</a>
        <a class="btn btn-select btn-primary" onClick="togglePanel()" id="player-btn"><i class="fa fa-play-circle"></i> Player</a>
    </div>
    <div class="clearfix"></div>
</div>

<div id="player-section" style="display:none;">
	<div class="form-title">Player <small>ตัวเล่นเพลง</small> </div>
	<div class="well" style="text-align:center;"><iframe id="player-iframe" src="" height="180" width="300" frameborder="0" allowtransparency="yes" scrolling="no"></iframe></div>
	<div class="form-panel">
<form class="form-horizontal" method="post">
           
  <div class="form-group">
    <label for="theme" class="col-sm-2 control-label">Theme</label><input type="hidden" id="theme" value="standard">
    <div class="col-sm-10">
		<div class="btn-group" data-toggle="buttons">
              <label class="btn btn-default active" onClick="changeValStation('theme','standard')"><input type="radio"> Standard</label> 
              <label class="btn btn-default" onClick="changeValStation('theme','html5')"><input type="radio"> Standard HTML5</label>        
              <label class="btn btn-default" onClick="changeValStation('theme','full')"><input type="radio"> Full</label>        
              <label class="btn btn-default" onClick="changeValStation('theme','mini')"><input type="radio"> Mini</label>        
              <label class="btn btn-default" onClick="changeValStation('theme','circle')"><input type="radio"> Circle</label>        
		</div>
    </div>
  </div>
  <div class="form-group">
    <label for="font" class="col-sm-2 control-label">Font</label><input type="hidden" id="font" value="supermarket">
    <div class="col-sm-10">
		<div class="btn-group" data-toggle="buttons">
              <label class="btn btn-default" onClick="changeValStation('font','none')"><input type="radio"> Standard</label>        
              <label class="btn btn-default active" onClick="changeValStation('font','supermarket')"><input type="radio"> Supermarket</label>        
		</div>
    </div>
  </div>
  <div class="form-group">
    <label for="channels" class="col-sm-2 control-label">Color</label><input type="hidden" id="color" value="000">
    <div class="col-sm-10">
        <select name="colorpicker-regularfont" id="select-color">
          <option value="#000">Black</option>
          <option value="#666">Gray</option>
          <option value="#3276b9">Blue</option>
          <option value="#46b8da">Sky</option>
          <option value="#5cb85c">Green</option>
          <option value="#d9534f">Red</option>
          <option value="#f0ad4e">Orange</option>
          <optgroup label="----------"></optgroup>
          <option value="#46d6db">Turquoise</option>
          <option value="#7ae7bf">Light green</option>
          <option value="#51b749">Bold green</option>
          <option value="#fbd75b">Yellow</option>
          <option value="#ffb878">Orange</option>
          <option value="#ff887c">Red</option>
          <option value="#dc2127">Bold red</option>
          <option value="#dbadff">Purple</option>
        </select>    
       
    </div>
  </div> 
  <div class="form-group">
    <label for="cover" class="col-sm-2 control-label">Cover Art</label>
    <div class="col-sm-10">
        <input type="text" id="cover" name="cover" placeholder="Cover: http://www.example.com/images.jpg (ความกว้าง 100x100)"   value="<?=$CONFIG->Setting("station","cover")?>" class="form-control col-lg-12">
	</div>
  </div>
  <div class="form-group">
    <label for="width" class="col-sm-2 control-label">Width</label>
    <div class="col-sm-10">
        <input type="number" id="width" name="width" value="300" class="form-control col-lg-2"> <span style="line-height:30px; padding-left:15px;">px</span>
	</div>
  </div>
  <div class="form-group">
    <label for="refresh" class="col-sm-2 control-label">Refrsh-Time</label>
    <div class="col-sm-10">
        <input type="number" id="refresh" name="refresh" value="30" class="form-control col-lg-2"> <span style="line-height:30px; padding-left:15px;">เวลาโหลดข้อมูลใหม่อัตโนมัติ (วินาที)</span>
	</div>
  </div>
  <div class="form-group">
    <label for="substr" class="col-sm-2 control-label">Songtitle</label>
    <div class="col-sm-10">
        <input type="number" id="substr" name="substr" value="40" class="form-control col-lg-2"> <span style="line-height:30px; padding-left:15px;">ย่อชื่อเพลงลงกี่ตัวอักษร</span>
	</div>
  </div>
  <div class="text-center" style="margin-bottom:15px;"><a class="btn btn-primary" onClick="GeneratedCode()">Generated HTML Code</a> </div>
  <div class="form-group">
    <label for="cover" class="col-sm-2 control-label">Code HTML</label>
    <div class="col-sm-10">
        <textarea  onMouseOver="javascript:this.focus();this.select();" style="height:80px; width:100%;" class="form-control" id="codehtml"><iframe id="player" frameborder="0" scrolling="no" width="'300'" height="180" src="<?=$CONFIG->Setting("station","lasturl")?>"></iframe></textarea>
	</div>
  </div>
  <div class="form-group">
    <label for="width" class="col-sm-2 control-label">Stream URL</label>
    <div class="col-sm-10">
        <input type="text"  onMouseOver="javascript:this.focus();this.select();"  id="url" name="url" value="http://<?=$CONFIG->Setting("system","ip")?>:<?=$CONFIG->Configuration("shoutcast","portbase")?>/listen.pls?sid=1" class="form-control col-lg-12" >
	</div>
  </div>
</form>             
<div class="alert alert-info">เมื่อ <strong>"Generated HTML Code"</strong> จะได้รับ <em>styleID</em> เป็นการย่อ URL ให้สั้นลงและรูปแบบจะเป็นไปตามที่เรากำหนด</div> 

</div>
</div>

<div id="comments-section">

<h3 class="fontsupermarket">จัดการการแสดงความคิดเห็น</h3>
<form action="<?=$_SERVER['PHP_SELF']?>?section=station&id=deleteallcomments" method="post" onSubmit="if(confirm('คุณแน่ใจที่จะลบรายการทั้งหมด ?')){return true;}else{return false;}">
	<div class="pull-left"><button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i> ลบทั้งหมด</button></div>
    <div class="clearfix"></div>
    <hr style="margin:5px;">
<table class="display comments-table">
	<thead>
    <tr>
    	<th class="text-center" width="10%">#</th>
        <th class="text-center" width="20%">ผู้ส่ง</th>
        <th class="text-center" width="55%">ข้อความ</th>
        <th class="text-center" width="20%">เวลา</th>
        <th class="text-center" width="5%">Action</th>
    </tr>
    </thead>
    <tbody>
<? 
$listComment = array();
$listComment = $STATION->listComment(); $i=1;
if($listComment!="") { 
foreach($listComment as $id=>$comment) {
?>
		<tr id="tr_<?=$id?>" style="background:<? echo($comment['read']=="no")?"#FFF1E2":"#F5FFEC"; ?>">
        	<td><?=$i?></td>
        	<td class="text-left"><small title="<?=$comment['ip']?>">[IP]</small> <?=$comment['name']?></td>
        	<td class="text-left"><?=$comment['comment']?></td>
            <td class="text-center"><span title="<?=ToTime($comment['time'],"d")?>"><?=generate_date_today("d M H:i", $comment['time'],"th")?></span></td>
            <td><a class="btn btn-xs btn-danger" title="ลบข้อความนี้" onClick="deleteItemComment('<?=$id?>')"><i class="fa fa-trash-o"></i></a></td>
        </tr>
<? $STATION->CommentUpdate($id,"read","yes"); $i++; } ?>
<? } else { echo ''; } ?>
    </tbody>
</table>
</form>

</div>

<script src="dist/js/jquery.simplecolorpicker.js"></script>
<link href="dist/css/jquery.simplecolorpicker.css" rel="stylesheet">
<link href="dist/js/datatables/dataTables.css" rel="stylesheet">
<script src="dist/js/datatables/dataTables.min.js"></script>
<script>
$(document).ready(function(e) {
	$("#codehtml").focus();
    $('select[name="colorpicker-regularfont"]').simplecolorpicker({theme: 'regularfont'});
	$("#cover").change(function(e) { saveStation(); preview();});
	$("#refresh").change(function(e) { preview(); });
	$("#substr").change(function(e) {preview(); });
	$("#width").change(function(){preview();});
	$("#select-color").change(function(){preview();});
	/* Comments */
 	$('.comments-table').dataTable({
	"sDom": 'fCl<"clear">rtip',
	"sPaginationType": "full_numbers",
	 "iDisplayLength": 50,
	 "aaSorting": [[0,"desc"]],
	  "aoColumns": [
			{ "sType": 'numeric' },null,null,null,{ "bSortable": false }
	  ]
	});
});
function deleteItemComment(comment) {
	if(confirm("คุณแน่ใจที่จะลบรายการนี้ ?")) {
		loader("show");
		$.post("dashboard.php?section=station&id=deletecomment",{"comment":comment}, function(data){
			if(data['result']=='ok') { 
				$.jGrowl(data['msg'], { header: 'iSong Control Panel',theme: 'smoke'} );
				$("#tr_"+comment).slideUp('fast');
			} else if(data['result']=='error') { 
				$.jGrowl(data['msg'], { header: 'iSong Control Panel',theme: 'red'} ); 
			}
			loader("unshow");
		}, "json");
	}
}

var baseURL = "<?=$CONFIG->Setting('site','baseurl')?>";
function saveStation() {
	loader("show");
	$.post("dashboard.php?section=station&id=player",{"do":"save","refresh":$("#refresh").val(),"substr":$("#substr").val(),"cover":$("#cover").val()}, function(data){
		loader("unshow");
	});
}
function GeneratedCode() {
	var theme = $("#theme").val(), font = $("#font").val(), valcolor = $('select[name="colorpicker-regularfont"]').val(),strsub = $("#substr").val(),refreshtime = $("#refresh").val(),iwidth = $("#width").val();
	var icolor = valcolor.substr(1);
	$.post("dashboard.php?section=station&id=player",{"do":"generated","theme":theme,"color":icolor,"font":font,"refresh":$("#refresh").val(),"substr":$("#substr").val(),"cover":$("#cover").val()}, function(data){
		switch(theme) {
			case "standard": var iheight="152"; break;
			case "html5": var iheight="152"; break;
			case "full": var iheight="202"; break;
			case "mini": var iheight="60"; break;
			case "circle": var iheight="75"; break;
		}
		var PlayerURL = baseURL+"station.php?id="+data['player_id'];
		var codehtml = '<iframe id="player" frameborder="0" scrolling="no" width="'+iwidth+'" height="'+iheight+'" src="'+PlayerURL+'"></iframe>';
		$("#codehtml").val(codehtml).focus().select();		
		loader("unshow");
	},"json");
}
function preview() {
	loader("show");
	var theme = $("#theme").val(), font = $("#font").val(), valcolor = $('select[name="colorpicker-regularfont"]').val(),strsub = $("#substr").val(),refreshtime = $("#refresh").val(),iwidth = $("#width").val();
	var icolor = valcolor.substr(1);
	switch(theme) {
		case "standard": var iheight="152"; break;
		case "html5": var iheight="152"; break;
		case "full": var iheight="202"; break;
		case "mini": var iheight="60"; break;
		case "circle": var iheight="75"; break;
	}
	if(theme=="full"){ if($("#width").val()<400){var iwidth="400";$("#width").val("400");} }
	var PreviewURL = baseURL+"station.php?theme="+theme+"&color="+icolor+"&font="+font+"&substr="+strsub+"&refresh="+refreshtime;
	var codehtml = '<iframe id="player" frameborder="0" scrolling="no" width="'+iwidth+'" height="'+iheight+'" src="'+PreviewURL+'"></iframe>';
	$("#codehtml").val(codehtml).focus().select();
	$("#player-iframe").attr("src",PreviewURL).delay(300).attr("height",iheight).attr("width",iwidth);
	loader("unshow");
}
function changeValStation(elementID, value) {
	$("#"+elementID).val(value);
	preview();
}
function togglePanel() {
	var showPanel = $("#show-panel").val();
	if(showPanel=="player") {
		$("#player-btn").removeClass("active"); $("#comments-btn").addClass("active");
		$("#player-section").slideUp("fast"); $("#comments-section").slideDown('fast'); $("#show-panel").val('comments');
		$("#player-iframe").attr("src","");
	} else if(showPanel=="comments") {
		$("#comments-btn").removeClass("active"); $("#player-btn").addClass("active");
		$("#comments-section").slideUp("fast");  $("#player-section").slideDown('fast');  $("#show-panel").val('player');
		preview();
	}

}
</script>
<style>
.form-panel { padding:10px; border:1px solid #EAEAEA; border-radius:6px; }
.form-title {font-family:supermarket; font-size:26px; font-weight:bold; margin-top:0px;  }
</style>