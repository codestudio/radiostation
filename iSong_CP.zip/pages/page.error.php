<?php
if($_GET["msg"]) {
	switch($_GET["msg"]) {
		case "404": $Msg = "404 Not found , หน้าที่คุณเรียกไม่พบ";  break;
		case "500": $Msg = "500 Internet server error , หน้าที่คุณเรียกเกิดข้อผิดผลาดในเซิฟเวอร์";  break;
	}
}
?>
<html lang="th">
<head>
<meta charset="utf-8">
<title>iSong Control Panel</title>
<link rel="stylesheet" href="dist/css/bootstrap.css">
<link rel="stylesheet" href="dist/css/style.css">
</head>

<body>
<div class="PanelMain" style="max-width:400px; margin-top:60px;">
	<h2 class="PanelMain-heading">เกิดข้อผิดผลาด</h2>
    <div class="alert alert-danger"><?=$Msg?></div>
    <div class="text-center">
    	<a class="btn btn-danger" href="javascript:history.back();"><i class="fa fa-backward"></i> ย้อนกลับ</a> 
        <a class="btn btn-primary" href="index.php"><i class="fa fa-home"></i> หน้าแรก</a> 
    </div>
</div>
</body>
</html>