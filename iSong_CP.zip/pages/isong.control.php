<?
/************************************************************************************
iSong - Control Panel by Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
?>
<div class="row">
	<div class="col-lg-6">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title text-center">SHOUTcast</h3>
          </div>
          <div class="panel-body">
            <div class="panel-status-btn"><a class="btn btn-block btn-lg btn-success isong-shoutcast-btn" data-status="" data-loading-text="Loading...">&nbsp;</a></div>
            <div class="panel-status text-green isong-shoutcast-text"></div>
          </div>
        </div>
    </div>
	<div class="col-lg-6">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title text-center">Transcoders</h3>
          </div>
          <div class="panel-body">
            <div class="panel-status-btn"><a class="btn btn-block btn-lg btn-success isong-transcoder-btn" data-status="" data-loading-text="Loading...">&nbsp;</a></div>
            <div class="panel-status text-red isong-transcoder-text"></div>
          </div>
        </div>
    </div>
</div>
<div class="form-title" style="margin-top:0px;">Control <small>ควบคุมระบบ</small> <div class="pull-right"><a onClick="toggleShow('shoutcast-control');" class="cursor-pointer">Show/Hide</a></div></div>
<div id="isong-control" class="form-panel">
	<div class="isong-control-btn">
    	<div class="row">
        	<div class="col-md-6 isong-control-shoutcast" style="display:none;"><div class="isong-control-text-header">SHOUTcast</div>
            <a class="btn btn-block btn-danger btn-radio-restart" onClick="Radio('restart')" data-loading-text="Loading...">Restart SHOUTcast</a>  
            <a class="btn btn-block btn-primary btn-radio-kick" onClick="Radio('kicksrc')" data-loading-text="Loading...">Kick DJ</a> 
            <a class="btn btn-block btn-primary btn-radio-reload" onClick="Radio('reload')" data-loading-text="Loading...">Reload configuration</a></div>
        	<div class="col-md-6 isong-control-transcoder" style="display:none;"><div class="isong-control-text-header">Transcoder</div>
            <a class="btn btn-block btn-danger btn-autodj-restart" onClick="AutoDJ('restart')" data-loading-text="Loading...">Restart Transcoder</a> 
            <a class="btn btn-block btn-primary btn-autodj-nextsong" onClick="AutoDJ('nextsong')" data-loading-text="Loading...">Next song</a> 
            <a class="btn btn-block btn-primary btn-autodj-loadplaylist" onClick="AutoDJ('loadplaylist')" data-loading-text="Loading...">Reload playlist</a></div>
        </div>
    </div>
</div>
<div class="isong-shoutcast-stats"></div>
<script>
$(document).ready(function(e) {
	iniStatus();
 	$(".isong-shoutcast-btn").live("click","",function(e){
		$(".isong-shoutcast-btn").button('loading');
		controlToggle("shoutcast");
	});
 	$(".isong-transcoder-btn").live("click","",function(e){
		$(".isong-transcoder-btn").button('loading');
		controlToggle("transcoder");
	});
	$(".isong-shoutcast-btn").live("mouseenter",function(e){ if($(this).attr("data-status")=="online") { $(this).html("Stop"); } if($(this).attr("data-status")=="offline") { $(this).html("Start"); } });
	$(".isong-shoutcast-btn").live("mouseleave",function(e){ if($(this).attr("data-status")=="online") { $(this).html("Online"); } if($(this).attr("data-status")=="offline") { $(this).html("Offline"); } });
	$(".isong-transcoder-btn").live("mouseenter",function(e){ if($(this).attr("data-status")=="online") { $(this).html("Stop"); } if($(this).attr("data-status")=="offline") { $(this).html("Start"); } });
	$(".isong-transcoder-btn").live("mouseleave",function(e){ if($(this).attr("data-status")=="online") { $(this).html("Online"); } if($(this).attr("data-status")=="offline") { $(this).html("Offline"); } });
});
</script>
<style>
#isong-control { margin-bottom:20px;}
.isong-control-btn { margin-bottom:10px; }
.isong-control-btn .row .col-md-5 { width:45%; }
.isong-control-text-header { text-align:center; font-size:19px; font-family:supermarket; font-weight:bold; margin-bottom:5px; }
.form-panel { padding:15px; border:1px solid #EAEAEA; border-radius:6px; margin:5px; background-color:#F2F2F2; }
.form-title {font-family:supermarket; font-size:26px; font-weight:bold; margin-top:30px;  }
.form-title .pull-right { font-size:13px; color:#000; line-height:30px;}
</style>