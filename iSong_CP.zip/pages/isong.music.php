<?
/************************************************************************************
iSong - Control Panel by Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
if(!$ISONG){die("Access denied!");}
require_once("include/getid3.php");
$_SESSION["targetDir"] = $CONFIG->Setting["system"]["path_music"];
$Playlist = new iSong_Playlist();
$Playlist->Generated();
?>
<div class="clearfix"></div>
<h3 class="fontsupermarket">จัดการรายการเพลง</h3>
<form action="<?=$_SERVER['PHP_SELF']?>?section=music&id=deletechecked" method="post" onSubmit="if(confirm('คุณแน่ใจที่จะลบรายการดังกล่าว ?')){return true;}else{return false;}">
<table class="display music-table">
	<thead>
    <tr>
    	<th class="text-center" width="10%"><input type="checkbox" class="check" name="check_toggle"></th>
        <th class="text-center" width="55%">Song title - Artist</th>
        <th class="text-center" width="15%">Size</th>
        <th class="text-center" width="15%">Action</th>
    </tr>
    </thead>
    <tbody>
<? $n=0; $i=1;
$opendir = ReadDirs($CONFIG->Setting["system"]["path_music"]);
foreach($opendir as $file_name) {
	$file_path = $CONFIG->Setting["system"]["path_music"].$file_name;
	$file_parts = pathinfo($file_name); $file=$file_parts['filename'];
	$id3 = read_tag($file_path);
?>
		<tr id="tr_<?=$file?>">
        	<td><?=$i?> <input type="checkbox" name="file_check[]" value="<?=$file?>"></td>
        	<td class="text-left">
                <span id="text_<?=$file?>" data-filename="<?=$file_name?>" onClick="editItem('<?=$file?>')"  style="cursor:pointer;"><?=Encoding::toUTF8($id3['title'])?> - <?=Encoding::toUTF8($id3['artist'])?></span>
                <div class="input-edit" id="div_<?=$file?>" style="display:none;">
                    <input type="text" id="id3_title_<?=$file?>" value="<?=$id3['title']?>" class="form-control col-lg-5 input-sm">
                    <input type="text" id="id3_artist_<?=$file?>" value="<?=$id3['artist']?>" class="form-control col-lg-5 input-sm">
                    <button class="btn btn-success btn-xs" type="button" onClick="saveItem('<?=$file?>')">Save</button>
                </div>
            </td>
            <td><?=view_size(filesize($file_path))?></td>
            <td><audio id="player_<?=$file?>"></audio>
                <a class="btn btn-xs btn-success" title="แก้ไขชื่อเพลง" onClick="editItem('<?=$file?>')"><i class="fa fa-pencil"></i></a>
                <a class="btn btn-xs btn-info" title="เล่นตัวอย่างเพลง" onClick="preview('<?=$file?>')"><i class="fa fa-play" id="icon-player_<?=$file?>"></i></a>
                <a class="btn btn-xs btn-danger" title="ลบเพลงนี้" onClick="deleteItem('<?=$file?>')"><i class="fa fa-trash-o"></i></a>
            </td>
        </tr>
<? $i++; } ?>
    </tbody>
</table>
	<div class="pull-left"><button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i> ลบทั้งหมดที่เลือกไว้</button>
   <a href="?page=music" class="btn btn-primary btn-sm"><i class="fa fa-refresh"></i> แสดงรายการใหม่</a></div>
    <div class="clearfix"></div>
</form>
<hr>

<h3 class="fontsupermarket">อัพโหลดเพลง</h3>
	<div id="uploader">
		<p>You browser doesn't have Flash, Silverlight, Gears, BrowserPlus or HTML5 support.</p>
	</div>
	<div class="font10">* เมื่ออัพโหลดเสร็จควรจะทำการ Refresh หน้านี้ใหม่เพื่อให้แสดงรายการเพลง</div>

<style>
.display-none, .input-edit .dataTables_wrapper div { display:none; }
.input-edit { line-height:20px; }
.input-edit input[type="text"] { height:22px; }
.input-edit .input-sm { margin-right:5px; padding-left:3px; padding-right:2px; }
.btn-xs { padding:2px 5px; font-size:6px; }
</style>
<link href="dist/js/datatables/dataTables.css" rel="stylesheet">
<script src="dist/js/datatables/dataTables.min.js"></script>
<link href="dist/js/plupload/jquery.plupload.queue/css/jquery.plupload.queue.css" rel="stylesheet" media="screen">
<script src="dist/js/plupload/plupload.full.js"></script>
<script src="dist/js/plupload/jquery.plupload.queue/jquery.plupload.queue.js"></script>
<script>
function editItem(filename) {
	var div = "div_"+filename, text = "text_"+filename, id3_title = "id3_title_"+filename, id3_artist = "id3_artist_"+filename;
	$("#"+div).removeAttr("style",""); $("#"+text).attr("style","display:none;"); $("#"+id3_title).focus();
}
function saveItem(filename) {
	loader("show");
	var div = "div_"+filename, text = "text_"+filename, id3_title = "id3_title_"+filename, id3_artist = "id3_artist_"+filename;
	var filetarget = $("#"+text).attr("data-filename");
	$.post("dashboard.php?section=music&id=save",{"title":$("#"+id3_title).val(), "artist":$("#"+id3_artist).val(),"filename":filetarget}, function(data){
		if(data['result']=='ok') { 
			$.jGrowl(data['msg'], { header: 'iSong Control Panel',theme: 'smoke'} );
			$("#"+text).html($("#"+id3_title).val()+' - '+$("#"+id3_artist).val()).removeAttr("style","");
			$("#"+div).attr("style","display:none;");
		} else if(data['result']=='error') { 
			$.jGrowl(data['msg'], { header: 'iSong Control Panel',theme: 'red'} ); 
		}
		loader("unshow");
	}, "json");
}
function deleteItem(filename) {
	var div = "div_"+filename, text = "text_"+filename;
	var filetarget = $("#"+text).attr("data-filename"); loader("show");
	if(confirm("คุณแน่ใจที่จะลบรายการนี้ ?")) {
		$.post("dashboard.php?section=music&id=delete",{"filename":filetarget}, function(data){
			if(data['result']=='ok') { 
				$.jGrowl(data['msg'], { header: 'iSong Control Panel',theme: 'smoke'} );
				$("#tr_"+filename).slideUp('fast');
			} else if(data['result']=='error') { 
				$.jGrowl(data['msg'], { header: 'iSong Control Panel',theme: 'red'} ); 
			}
		loader("unshow");
		}, "json");
	}
}
function preview(filename) {
	loader("show");
	var div = "player_"+filename, file = $("#text_"+filename).attr("data-filename"), folder = "<?=$CONFIG->Setting["system"]["path_music_url"]?>";
	var player = document.getElementById(div);
	var path_file = folder+file;
	if(player.src=="") { 
		loader("unshow");
		player.src=path_file; player.play();
		$("#icon-player_"+filename).removeClass("fa-play").addClass("fa-pause");
	} else {
		loader("unshow");
		if(player.paused == false) { 
			player.pause();
			$("#icon-player_"+filename).removeClass("fa-pause").addClass("fa-play");
		 } else {
			player.play();
			$("#icon-player_"+filename).removeClass("fa-play").addClass("fa-pause");
		}
	}
}
$(document).ready(function() {
	
    $('.check').toggle(function(){
		$(this).attr('checked','checked');
        $('input:checkbox').attr('checked','checked');
    },function(){
		$(this).removeAttr('checked');
        $('input:checkbox').removeAttr('checked');
    })
		$("#uploader").pluploadQueue({
					runtimes: 'html5,flash,html4',
					url : 'backend/music.upload.php',
					max_file_size : '15mb',
					unique_names : true, 
					flash_swf_url : 'dist/js/plupload/plupload.flash.swf',
					filters : [
						{title : "MP3 files", extensions : "mp3"},
					],
					
	});
 	$('.music-table').dataTable({
	"sDom": 'fCl<"clear">rtip',
	"sPaginationType": "full_numbers",
	 "iDisplayLength": 50,
	 "aaSorting": [],
	  "aoColumns": [
			{ "bSortable": false },null,null,{ "bSortable": false }
	  ]
	});
});
</script>