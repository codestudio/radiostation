<?
/************************************************************************************
iSong - Control Panel by Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
if(!$ISONG){die("Access denied!");}
?>
<table class="display logs-table">
	<thead>
    <tr>
    	<th class="text-center" width="5%">#</th>
        <th class="text-center" width="40%">Filename</th>
        <th class="text-center" width="25%">Date</th>
        <th class="text-center" width="10%">Action</th>
    </tr>
    </thead>
    <tbody>
<? $n=0; $i=1;
$opendir = ReadDirs($CONFIG->Setting["system"]["path_backend"]."logs/");
foreach($opendir as $file_name) {
	$file_path = $CONFIG->Setting["system"]["path_backend"]."logs/".$file_name;
	$file_parts = pathinfo($file_name); $file=$file_parts['filename'];
	if($file_parts['extension']=="log") {
?>
		<tr id="tr_<?=$file?>">
        	<td><?=$i?></td>
        	<td class="text-left"><a id="text_<?=$file?>" data-filename="<?=$file?>" style="color:#000; cursor:pointer;" onClick="preview('<?=$file?>')"><i class="fa fa-eye"></i> <?=($file_name)?></a></td>
            <td><?=date ("d-m-Y [H:i:s]", filemtime($file_path))?></td>
            <td><a class="btn btn-xs btn-info" title="ดูรายการนี้" onClick="preview('<?=$file?>')"><i class="fa fa-eye"></i></a> <a class="btn btn-xs btn-danger" title="ลบรายการนี้" onClick="deleteItem('<?=$file?>')"><i class="fa fa-trash-o"></i></a></td>
        </tr>
<? $i++; } else { @unlink($file_path); } } ?>
    </tbody>
</table>
<style>
.btn-xs { padding:2px 5px; font-size:6px; }
</style>
<div class="modal fade" id="viewLogs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">View logs: </h4>
      </div>
      <div class="modal-body"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<link href="dist/js/datatables/dataTables.css" rel="stylesheet">
<script src="dist/js/datatables/dataTables.min.js"></script>
<script>
function deleteItem(filename) { loader("show");
	var div = "div_"+filename, text = "text_"+filename;
	var filetarget = $("#"+text).attr("data-filename");
	if(confirm("คุณแน่ใจที่จะลบรายการนี้ ?")) {
		$.post("dashboard.php?section=logs&id=delete",{"filename":filetarget}, function(data){
			if(data['result']=='ok') { 
				$.jGrowl("ทำการลบรายการดังกล่าวแล้ว", { header: 'iSong Control Panel',theme: 'smoke'} );
				$("#tr_"+filename).slideUp('fast');
			} else if(data['result']=='error') { 
				$.jGrowl(data['msg'], { header: 'iSong Control Panel',theme: 'red'} ); 
			}
			loader("unshow");
		}, "json");
	}
}
function htmlForTextWithEmbeddedNewlines(text) {
    var htmls = [];
    var lines = text.split(/\n/);
    var tmpDiv = jQuery(document.createElement('div'));
    for (var i = 0 ; i < lines.length ; i++) {
        htmls.push(tmpDiv.text(lines[i]).html());
    }
    return htmls.join("<br>");
}
function preview(filename) { loader("show");
	var div = "player_"+filename, text = "text_"+filename, file = $("#text_"+filename).attr("data-filename");
	var filetarget = $("#"+text).attr("data-filename");
	$.post("dashboard.php?section=logs&id=view",{"filename":filetarget}, function(data){
		$(".modal-title").html("View logs: "+data['filename']);
		$(".modal-body").html(htmlForTextWithEmbeddedNewlines(data['result']));
		$(".modal").modal('show');
		loader("unshow");
	},"json");
}
$(document).ready(function() {
 	$('.logs-table').dataTable({
	"sDom": 'fCl<"clear">rtip',
	"sPaginationType": "full_numbers",
	 "iDisplayLength": 50,
	 "aaSorting": [],
	  "aoColumns": [
			null,null,null,{ "bSortable": false }
	  ]
	});
});
</script>