<?
/************************************************************************************
iSong - Control Panel by Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
if(!$ISONG){die("Access denied!");}
?>
<? if($_SESSION["msg_ok"]!=""){?><div class="alert alert-success"><i class="fa fa-check"></i> <?=$_SESSION["msg_ok"]?></div><? $_SESSION["msg_ok"]="";}?>

<div class="form-title" style="margin-top:0px;">SHOUTcast <div class="pull-right"><a onClick="toggleShow('form-shoutcast');" class="cursor-pointer">Show/Hide</a></div> </div>
<form class="form-horizontal form-panel" id="form-shoutcast" action="<?=$_SERVER['PHP_SELF']?>?section=configuration&id=shoutcast" method="post">
<div class="section"><h4><span>Basic configuration</span> <div class="pull-right text-sm"><a class="btn btn-xs btn-default " href="<?=$_SERVER['PHP_SELF']?>?section=configuration&id=reset&config=shoutcast"><i class="fa fa-refresh"></i> ใช้การตั้งค่าเดิม</a> </div> </h4> 
  <div class="form-group">
    <label for="password" class="col-sm-3 control-label">Password <span class="help-block">รหัสสำหรับ Broadcasters</span> </label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="password" placeholder="Password" name="password" required value="<?=$CONFIG->Configuration("shoutcast","password")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="adminpassword" class="col-sm-3 control-label">Admin Password <span class="help-block">รหัสสำหรับเข้าจัดการ</span> </label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="adminpassword" placeholder="Admin Password" name="adminpassword" required value="<?=$CONFIG->Configuration("shoutcast","adminpassword")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="portbase" class="col-sm-3 control-label">Portbase <span class="help-block">Portbase ของ Radio</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-2 form-config" id="portbase" placeholder="Portbase" name="portbase" value="<?=$CONFIG->Configuration("shoutcast","portbase")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="maxuser" class="col-sm-3 control-label">Maximum listens <span class="help-block">จำนวนผู้ฟังสูงสุด</span></label>
    <div class="col-sm-9">
      <input type="number" class="form-control col-lg-2 form-config" id="maxuser"  min="1" placeholder="Maximum" name="maxuser" value="<?=$CONFIG->Configuration("shoutcast","maxuser")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="publicserver" class="col-sm-3 control-label">Public Server <span class="help-block">รูปแบบสาธารณะ</span></label>
    <div class="col-sm-9"><input type="hidden" name="publicserver" id="publicserver" value="<?=$CONFIG->Configuration("shoutcast","publicserver")?>">
        <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-default<? echo($CONFIG->Configuration("shoutcast","publicserver")=="always")?" active":""; ?>" onClick="changeVal('publicserver','always')" value="always"><input type="radio"> สาธารณะ</label>
            <label class="btn btn-default<? echo($CONFIG->Configuration("shoutcast","publicserver")=="never")?" active":""; ?>" onClick="changeVal('publicserver','never')" value="never"><input type="radio"> ส่วนตัว</label>
        </div>
    </div>
  </div>
  
  <div class="form-group">
    <label for="songhistory" class="col-sm-3 control-label">Song history <span class="help-block">บันทึกรายการเพลงย้อนหลัง</span></label>
    <div class="col-sm-9">
      <input type="number" class="form-control col-lg-2 form-config" id="songhistory" min="0" max="100" name="songhistory" value="<?=$CONFIG->Configuration("shoutcast","songhistory")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="titleformat" class="col-sm-3 control-label">Title format <span class="help-block">ค่า %s คือชื่อจากสถานี</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="titleformat" name="titleformat" value="<?=$CONFIG->Configuration("shoutcast","titleformat")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="urlformat" class="col-sm-3 control-label">URL format <span class="help-block">URL ของสถานี</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="urlformat" name="urlformat" value="<?=$CONFIG->Configuration("shoutcast","urlformat")?>">
    </div>
  </div>
</div> 
<hr>  
<div class="section"><h4><span>Advance configuration</span></h4> 
  <div class="form-group">
    <label for="cpucount" class="col-sm-3 control-label">CPU Count <span class="help-block">จำนวนที่ทำให้ CPU ทำงาน</span></label>
    <div class="col-sm-9">
      <input type="number" class="form-control col-lg-2 form-config" id="cpucount" min="0" max="20" name="cpucount" value="<?=$CONFIG->Configuration("shoutcast","cpucount")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="autodumpsourcetime" class="col-sm-3 control-label"> Auto-Dump Time <span class="help-block">เมื่อไม่มีสัญญาเชื่อมต่อ (วินาที)</span></label>
    <div class="col-sm-9">
       <input type="number" class="form-control col-lg-2 form-config" id="autodumpsourcetime" min="0" name="autodumpsourcetime" value="<?=$CONFIG->Configuration("shoutcast","autodumpsourcetime")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="streampath" class="col-sm-3 control-label">StreamPath <span class="help-block">ที่อยู่ของตัวเล่นเพลง</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="streampath" placeholder="Stream Path" name="streampath" value="<?=$CONFIG->Configuration("shoutcast","streampath")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="streamurl" class="col-sm-3 control-label">StreamURL <span class="help-block">URL ของสถานี</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="streamurl" placeholder="Stream URL" name="streamurl" value="<?=$CONFIG->Configuration("shoutcast","streamurl")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="logs" class="col-sm-3 control-label">Logs <span class="help-block">เปิด Logs </span></label>
    <div class="col-sm-9"><input type="hidden" name="log" id="logs_shoutcast" value="<?=$CONFIG->Configuration("shoutcast","log")?>">
        <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-default<? echo($CONFIG->Configuration("shoutcast","log")=="1")?" active":""; ?>" onClick="changeVal('logs_shoutcast','1')"><input type="radio"> เปิด</label>
            <label class="btn btn-default<? echo($CONFIG->Configuration("shoutcast","log")=="0")?" active":""; ?>" onClicfk="changeVal('logs_shoutcast','0')"><input type="radio"> ปิด</label>
        </div>
    </div>
  </div>
</div>

  <div class="form-group">
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Save</button> <span class="text-sm">เมื่อบันทึกแล้ว, ต้องทำการ "Restart" ระบบด้วยตนเองเพื่อใช้การตั้งค่าใหม่นี้</span>
    </div>
  </div>
</form>

<div class="form-title">SHOUTcast Transcoder <div class="pull-right"><a onClick="toggleShow('form-transcoder');" class="cursor-pointer">Show/Hide</a></div> </div>
<form class="form-horizontal form-panel" id="form-transcoder" action="<?=$_SERVER['PHP_SELF']?>?section=configuration&id=transcoder" method="post">
    <div class="btn-group" data-toggle="buttons" style="width:100%;">
    	<input type="hidden" name="remote_host" id="remote_host" value="<?=$CONFIG->Configuration("transcoder","remote_host")?>">
        <label class="btn btn-select btn-primary<? echo($CONFIG->Configuration("transcoder","remote_host")=="local")?" active":""; ?>" onClick="transcoderRemote('local')"><input type="radio"> Local host</label>
		<label class="btn btn-select btn-success<? echo($CONFIG->Configuration("transcoder","remote_host")=="remote")?" active":""; ?>" onClick="transcoderRemote('remote')"><input type="radio"> Remote host</label>
    </div>
    <div class="clearfix"></div>
<div class="section" style="margin-top:15px;"><h4><span>Server configuration</span> <div class="pull-right text-sm"><a class="btn btn-xs btn-default " href="<?=$_SERVER['PHP_SELF']?>?section=configuration&id=reset&config=transcoder"><i class="fa fa-refresh"></i> ใช้การตั้งค่าเดิม</a> </div> </h4> 
  <div class="form-group">
    <label for="password" class="col-sm-3 control-label">SHOUTcast Version <span class="help-block">เวอชั่นของระบบ SHOUTcast</span> </label>
    <div class="col-sm-9">
      <select name="outprotocol" id="outprotocol" class="form-control">
		<option value="1"<? echo($CONFIG->Configuration("transcoder","outprotocol")=="1")?" selected":""; ?>>SHOUTcast 1 (Legacy)</option>
        <option value="2"<? echo($CONFIG->Configuration("transcoder","outprotocol")=="2")?" selected":""; ?>>Ultravox (Ultravox 2.0)</option>    
        <option value="3"<? echo($CONFIG->Configuration("transcoder","outprotocol")=="3")?" selected":""; ?>>SHOUTcast 2 (Ultravox 2.1)</option> 
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="serverip" class="col-sm-3 control-label">Server IP <span class="help-block">IP สำหรับเชื่อมต่อ</span> </label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-4 form-config" id="serverip" placeholder="Server IP" name="serverip" required value="<?=$CONFIG->Configuration("transcoder","serverip")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="password" class="col-sm-3 control-label">Server Password <span class="help-block">รหัสสำหรับเชื่อมต่อ</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-4 form-config" id="password_transcoder" placeholder="Password" name="password" value="<?=$CONFIG->Configuration("transcoder","password")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="serverport" class="col-sm-3 control-label">Server Port <span class="help-block">Portbase สำหรับเชื่อมต่อ</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-2 form-config" id="serverport" placeholder="Server Port" name="serverport" value="<?=$CONFIG->Configuration("shoutcast","portbase")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="public" class="col-sm-3 control-label">Server Public <span class="help-block">รูปแบบสาธารณะ</span></label>
    <div class="col-sm-9"><input type="hidden" name="public" id="public" value="<?=$CONFIG->Configuration("transcoder","public")?>">
        <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","public")=="1")?" active":""; ?> public_1" onClick="changeVal('public','1')"><input type="radio"> เซิฟเวอร์สาธารณะ</label>
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","public")=="0")?" active":""; ?> public_0" onClick="changeVal('public','0')"><input type="radio"> เซิฟเวอร์ส่วนตัว</label>
        </div>
    </div>
  </div>
  <div class="form-group">
    <label for="streamid" class="col-sm-3 control-label">Stream ID <span class="help-block">ID stream ของ SHOUTcast</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-2 form-config" id="streamid" name="streamid" value="<?=$CONFIG->Configuration("transcoder","streamid")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="endpointname" class="col-sm-3 control-label">Endpoint <span class="help-block">ที่อยู่ของตัวเล่นเพลง</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-4 form-config" id="endpointname" placeholder="Stream Path" name="endpointname" value="<?=$CONFIG->Configuration("transcoder","endpointname")?>">
    </div>
  </div>
</div>
<hr>  
<div class="section"><h4><span>Basic configuration</span></h4> 
  <div class="form-group">
    <label for="streamtitle" class="col-sm-3 control-label">Stream Title<span class="help-block">ชื่อของระบบ AutoDJ</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="streamtitle" name="streamtitle" value="<?=$CONFIG->Configuration("transcoder","streamtitle")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="streamurl" class="col-sm-3 control-label">Stream URL<span class="help-block">URL ของระบบ AutoDJ</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="streamurl" name="streamurl" value="<?=$CONFIG->Configuration("transcoder","streamurl")?>">
    </div>
  </div>
<?
$Genre = array("iSong","Tophits","Thai","Inter","Alternative","Blues","Classical","Country","Decades","Easy Listening","Electronic","Folk","Inspirational","Jazz","Latin","Metal","Misc","New Age","Pop","Public Radio","R&amp;B and Urban","Rap","Reggae","Rock","Soundtracks","Talk","Themes");
?>
  <div class="form-group">
    <label for="genre" class="col-sm-3 control-label">Genre<span class="help-block">ประเภทของเพลง</span></label>
    <div class="col-sm-9">
        <select name="genre" id="genre" class="form-control" data-placeholder="Choose a Genre">
        <? foreach($Genre as $Item) { ?>
            <option value="<?=$Item?>"<? if($CONFIG->Configuration("transcoder","genre")==$Item) { echo " selected"; } ?>><?=$Item?></option>
        <? } ?>

        </select>
    </div>   
   </div>
  <div class="form-group">
    <label for="adminport" class="col-sm-3 control-label">Admin Port<span class="help-block">Port ของระบบ AutoDJ</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-2 form-config" id="adminport" name="adminport" value="<?=$CONFIG->Configuration("transcoder","adminport")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="adminpass" class="col-sm-3 control-label">Admin Password<span class="help-block">รหัสผ่านจัดการระบบ AutoDJ</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-6 form-config" id="adminpass" name="adminpass" value="<?=$CONFIG->Configuration("transcoder","adminpass")?>">
    </div>
  </div>
</div>
<hr>
<div class="section"><h4><span>Encoder configuration</span></h4>
  <div class="form-group">
    <label for="bitrate" class="col-sm-3 control-label">Bitrate <span class="help-block">คุณภาพเสียง</span> </label>
    <div class="col-sm-9">
        <select name="bitrate" id="bitrate" class="form-control col-lg-4">
        <option value="3200"<? if($CONFIG->Configuration("transcoder","bitrate")==3200) { echo " selected"; } ?>>32 kbps</option>
        <option value="6400"<? if($CONFIG->Configuration("transcoder","bitrate")==6400) { echo " selected"; } ?>>64 kbps</option>
        <option value="9600"<? if($CONFIG->Configuration("transcoder","bitrate")==9600) { echo " selected"; } ?>>96 kbps</option>
        <option value="128000"<? if($CONFIG->Configuration("transcoder","bitrate")==128000) { echo " selected"; } ?>>128 kbps</option>
        <option value="198000"<? if($CONFIG->Configuration("transcoder","bitrate")==198000) { echo " selected"; } ?>>198 kbps</option>
        <option value="320000"<? if($CONFIG->Configuration("transcoder","bitrate")==320000) { echo " selected"; } ?>>320 kbps</option>
        </select>
    </div>
  </div>
  <div class="form-group">
    <label for="mp3quality" class="col-sm-3 control-label">MP3 Quality <span class="help-block">คุณภาพไฟล์เพลง</span> </label>
    <div class="col-sm-9"><input type="hidden" id="mp3quality" name="mp3quality" value="<?=$CONFIG->Configuration("transcoder","mp3quality")?>">
        <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","mp3quality")=="1")?" active":""; ?>" onClick="changeVal('mp3quality','1')"><input type="radio"> Hight Quality</label>
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","mp3quality")=="0")?" active":""; ?>" onClick="changeVal('mp3quality','0')"><input type="radio"> Fast Quality</label>
        </div>
    </div>
  </div>
  <div class="form-group">
    <label for="mp3mode" class="col-sm-3 control-label">MP3 Mode <span class="help-block">ประเภทไฟล์เพลง</span> </label>
    <div class="col-sm-9">
		<select name="mp3mode" id="mp3mode" class="form-control col-lg-4">
			<option value="0"<? if($CONFIG->Configuration("transcoder","mp3mode")=="0") { echo " selected"; } ?>>CBR (0)</option>
			<option value="1"<? if($CONFIG->Configuration("transcoder","mp3mode")=="1") { echo " selected"; } ?>>VBR - Highest (1)</option>
			<option value="2"<? if($CONFIG->Configuration("transcoder","mp3mode")=="2") { echo " selected"; } ?>>VBR - High (2)</option>
			<option value="3"<? if($CONFIG->Configuration("transcoder","mp3mode")=="3") { echo " selected"; } ?>>VBR - Medium (3)</option>
			<option value="4"<? if($CONFIG->Configuration("transcoder","mp3mode")=="4") { echo " selected"; } ?>>VBR - Lower (4)</option>
 			<option value="5"<? if($CONFIG->Configuration("transcoder","mp3mode")=="5") { echo " selected"; } ?>>VBR - Lowest (5)</option>
		</select> 
    </div>
  </div>
  <div class="form-group">
    <label for="channels" class="col-sm-3 control-label">MP3 Channels <span class="help-block">คุณภาพไฟล์เพลง</span> </label>
    <div class="col-sm-9"><input type="hidden" id="channels" name="channels" value="<?=$CONFIG->Configuration("transcoder","channels")?>">
        <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","channels")=="1")?" active":""; ?>" onClick="changeVal('channels','1')"><input type="radio">Mono</label>
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","channels")=="2")?" active":""; ?>" onClick="changeVal('channels','2')"><input type="radio">Stereo</label>
        </div>
    </div>
  </div>
  <div class="form-group">
    <label for="shuffle" class="col-sm-3 control-label">Shuffle <span class="help-block">การสุ่มเล่นเพลง</span></label>
    <div class="col-sm-9"><input type="hidden" id="shuffle" name="shuffle" value="<?=$CONFIG->Configuration("transcoder","shuffle")?>">
        <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","shuffle")=="1")?" active":""; ?>" onClick="changeVal('shuffle','1')"><input type="radio"> เล่นสุ่ม</label>
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","shuffle")=="0")?" active":""; ?>" onClick="changeVal('shuffle','0')"><input type="radio"> ไม่สุ่ม</label>
        </div>
    </div>
  </div>
  <div class="form-group">
    <label for="samplerate" class="col-sm-3 control-label">Samplerate<span class="help-block">Rate ไฟล์เพลง (44100)</span></label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-2 form-config" id="samplerate" name="samplerate" value="<?=$CONFIG->Configuration("transcoder","samplerate")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="xfade" class="col-sm-3 control-label">Crossfade length <span class="help-block">Crossfade เปลี่ยนเพลง (0 ไม่มี)</span></label>
    <div class="col-sm-9">
      <input type="number" class="form-control col-lg-2 form-config" id="xfade" min="0" name="xfade" value="<?=$CONFIG->Configuration("transcoder","xfade")?>">
    </div>
  </div>
  <div class="form-group">
    <label for="logs" class="col-sm-3 control-label">Logs <span class="help-block">เปิด Logs </span></label>
    <div class="col-sm-9"><input type="hidden" name="log" id="logs_transcoder" value="<?=$CONFIG->Configuration("transcoder","log")?>">
        <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","log")=="1")?" active":""; ?>" onClick="changeVal('logs_transcoder','1')"><input type="radio"> เปิด</label>
            <label class="btn btn-default<? echo($CONFIG->Configuration("transcoder","log")=="0")?" active":""; ?>" onClick="changeVal('logs_transcoder','0')"><input type="radio"> ปิด</label>
        </div>
    </div>
  </div>
</div>
  <div class="form-group">
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Save</button> <span class="text-sm">เมื่อบันทึกแล้ว, ต้องทำการ "Restart" ระบบด้วยตนเองเพื่อใช้การตั้งค่าใหม่นี้</span>
    </div>
  </div>
</form>

<script>
function transcoderRemote(remote) {
	if(remote=="local"){var JSONdata='<?=json_encode(array("remote"=>"local","outprotocol"=>"3","serverip"=>$CONFIG->Setting("system","ip"),"serverport"=>$CONFIG->Configuration("shoutcast","portbase"),"password"=>$CONFIG->Configuration("shoutcast","password"),"streamid"=>"1","endpointname"=>"/iSong"));?>';}
	if(remote=="remote"){var JSONdata='<?=json_encode(array("remote"=>"remote","outprotocol"=>$CONFIG->Configuration("transcoder","outprotocol"),"serverip"=>$CONFIG->Configuration("transcoder","serverip"),"serverport"=>$CONFIG->Configuration("transcoder","serverport"),"password"=>$CONFIG->Configuration("transcoder","password"),"streamid"=>$CONFIG->Configuration("transcoder","streamid"),"endpointname"=>$CONFIG->Configuration("transcoder","endpointname")));?>';}
	var data = $.parseJSON(JSONdata);
		$('#outprotocol option[value="'+data['outprotocol']+'"]').attr("selected","selected");
		$("#serverip").val(data['serverip']);
		$("#password_transcoder").val(data['password']);
		$("#serverport").val(data['serverport']);
		if(data['public']==1) { $(".public_0").removeClass("active"); $(".pubilc_1").addClass("active"); } else if(data['public']==0) { $(".pubilc_1").removeClass("active"); $(".pubilc_0").addClass("active"); }
		changeVal('public',data['public']);
		changeVal('remote_host',remote);
		$("#streamid").val(data['streamid']);
		$("#endpointname").val(data['endpointname']);
}
</script>
<style>
.section h4 { font-size:20px; }
.form-panel { padding:10px; border:1px solid #EAEAEA; border-radius:6px; }
.form-title {font-family:supermarket; font-size:26px; font-weight:bold; margin-top:30px;  }
.form-title .pull-right { font-size:13px; color:#000; line-height:30px;}
.form-horizontal .control-label { padding-top:0px; }
.form-group { margin-bottom:2px; }
.col-sm-9 { line-height:57px; }
.form-config { display:inline; }
.help-block { margin-top:-2px; font-size:10px; }
.btn-group { display:inline; }
</style>