    <div class="navbar navbar-inverse navbar-fixed-top fontsupermarket" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand font20" href="dashboard.php"><?=$CONFIG->Setting("site","short_title")?></a>
        </div>
        <ul class="nav navbar-nav font16">
          <li<? if($header=="dashboard")echo' class="active"';?>><a href="dashboard.php"><i class="fa fa-home"></i> หน้าแรก</a></li>
          <li<? if($header=="control")echo' class="active"';?>><a href="dashboard.php?page=control" title="ควบคุม เปิด-ปิด"><i class="fa fa-cog"></i> Control</a></li>
          <li<? if($header=="configuration")echo' class="active"';?>><a href="dashboard.php?page=configuration" title="ตั้งค่าระบบ"><i class="fa fa-cogs"></i> Configuration</a></li>
          <li<? if($header=="music")echo' class="active"';?>><a href="dashboard.php?page=music" title="จัดการเพลง"><i class="fa fa-music"></i> Music</a></li>
          <li class="dropdow<? if($header=="station")echo'active';?>n">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="รับฟังเพลงจากสถานี"><i class="fa fa-play-circle"></i> Players <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="dashboard.php?page=station&id=player" title="กล่องรับฟังเพลง"><i class="fa fa-play"></i> Player</a></li>
              <li><a href="dashboard.php?page=station&id=request" title="กล่องรับฟังเพลง"><i class="fa fa-comments"></i> Comments</a></li>
            </ul>
          </li>
        </ul>
        <div class="navbar-collapse collapse navbar-right">
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Account <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="dashboard.php?page=system"><i class="fa fa-edit"></i> แก้ไขข้อมูลส่วนตัว</a></li>
              <li class="divider"></li>
              <li><a href="index.php?do=logout"><i class="fa fa-sign-out"></i> ออกจากระบบ</a></li>
            </ul>
          </li>
        </ul>
        </div><!--/.navbar-collapse -->
      </div>
    </div>