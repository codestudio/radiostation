<?
/************************************************************************************
iSong - Control Panel by Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
if(!$ISONG){die("Access denied!");}
switch($_GET["section"]) {
case "configuration":
	if($_GET["id"]=="reset") :
		$shoutcast = array(
		"password"=>"pass",
		"adminpassword"=>"adminpass",
		"portbase"=>"8000",
		"maxuser"=>"100",
		"publicserver"=>"never",
		"songhistory"=>"10",
		"titleformat"=>"iSong Control Panel @ %s ",
		"urlformat"=>"http://www.isong.in.th/",
		"cpucount"=>"2",
		"autodumpsourcetime"=>"30",
		"streampath"=>"/iSong",
		"streamurl"=>"http://www.isong.in.th/",
		"log"=>"1",
		);
		$transcoder = array(
		"remote_host"=>"local",
		"outprotocol"=>"3",
		"serverip"=>"127.0.0.1",
		"password"=>"pass",
		"serverport"=>"8000",
		"public"=>"0",
		"adminport"=>"8002",
		"adminpass"=>"adminpass",
		"streamid"=>"1",
		"endpointname"=>"/iSong",
		"streamtitle"=>"AutoDJ",
		"streamurl"=>"http://www.isong.in.th/",
		"genre"=>"iSong",
		"bitrate"=>"128000",
		"mp3quality"=>"0",
		"mp3mode"=>"0",
		"channels"=>"2",
		"shuffle"=>"1",
		"samplerate"=>"44100",
		"xfade"=>"3",
		"log"=>"1",
		);
	
		if($_GET["config"]=="shoutcast") {
			$CONFIG->ConfigUpdate("configuration","shoutcast",$shoutcast);
			$_SESSION["msg_ok"]="เริ่มต้นการตั้งค่าใหม่ (SHOUTcast)";
			$ConfigGenerated = new iSong_Configuration(); $ConfigGenerated->Shoutcast(); // Generated config file
			PageMSG("ตั้งค่า SHOUTcast Configuration ใหม่เรียบร้อยแล้ว",true,"dashboard.php?page=configuration");
		}
		if($_GET["config"]=="transcoder") {
			$CONFIG->ConfigUpdate("configuration","transcoder",$transcoder);
			$_SESSION["msg_ok"]="เริ่มต้นการตั้งค่าใหม่ (Transcoder)";
			$ConfigGenerated = new iSong_Configuration(); $ConfigGenerated->Transcoder(); // Generated config file
			PageMSG("ตั้งค่า Transcoder Configuration ใหม่เรียบร้อยแล้ว",true,"dashboard.php?page=configuration");
		}
	exit(); endif;

	if($_GET["id"]=="shoutcast") :
		$ArraySetting = array("password","adminpassword","portbase","maxuser","publicserver","songhistory","titleformat","urlformat","cpucount","autodumpsourcetime","streampath","streamurl","log");
		foreach($ArraySetting as $key) { $newXML[$key] = trim($_POST[$key]); }
		$CONFIG->ConfigUpdate("configuration","shoutcast",$newXML);
		$_SESSION["msg_ok"]="บันทึกข้อมูลเรียบร้อยแล้ว (SHOUTcast)";
		$ConfigGenerated = new iSong_Configuration(); $ConfigGenerated->Shoutcast(); // Generated config file
		PageMSG("บันทึกข้อมูล SHOUTcast Configuration เรียบร้อยแล้ว",true,"dashboard.php?page=configuration");
		
	exit(); endif;
	if($_GET["id"]=="transcoder") :
		$ArraySetting = array("remote_host","outprotocol","serverip","password","serverport","public","adminport","adminpass","streamid","endpointname","streamtitle","streamurl","genre","bitrate","mp3quality","mp3mode","channels","shuffle","samplerate","xfade","log");
		foreach($ArraySetting as $key) {$newXML[$key] = trim($_POST[$key]); }
		$CONFIG->ConfigUpdate("configuration","transcoder",$newXML);
		$_SESSION["msg_ok"]="บันทึกข้อมูลเรียบร้อยแล้ว (Transcoder)";
		$ConfigGenerated = new iSong_Configuration(); $ConfigGenerated->Transcoder(); // Generated config file
		PageMSG("บันทึกข้อมูล SHOUTcast Transcoder Configuration เรียบร้อยแล้ว",true,"dashboard.php?page=configuration");
		
	exit(); endif;
die("Access denied."); break;

case "music" :
	if($_GET["id"]=="deletechecked") : 
	$i=1;
	if(!is_array($_POST["file_check"])) { PageMSG("ไม่พบรายการไฟล์ที่เลือก",false,"dashboard.php?page=music"); }
		foreach($_POST["file_check"] as $value){
			$target_file = $CONFIG->Setting["system"]["path_music"].$value.".mp3";
			if(!file_exists($target_file)) { PageMSG("ไม่พบไฟล์ <strong>".$value.".mp3</strong> ในระบบ",false,"dashboard.php?page=music"); }
			if(@unlink($target_file)) {
				PageMSG("ลบทั้งหมด <strong>".$i."</strong> รายการเรียบร้อยแล้ว",true,"dashboard.php?page=music");
				$i++;
			} else {PageMSG("ไม่สามารถลบไฟล์ <strong>".$value.".mp3</strong> ได้",false,"dashboard.php?page=music");}
		}
	exit(); endif;
	if($_GET["id"]=="save") :
		if($_POST["title"]==""){echo json_encode(array("msg"=>"กรุณากรอก ชื่อ เพลง","result"=>"error"));exit(); }
		if($_POST["filename"]==""){echo json_encode(array("msg"=>"กรุณาเลือกเพลง","result"=>"error"));exit(); }
		$target_file = $CONFIG->Setting["system"]["path_music"].$_POST["filename"];
		if(!file_exists($target_file)) {echo json_encode(array("msg"=>"ไม่พบไฟล์เพลงนี้ในระบบ","result"=>"error"));exit(); }
		require_once("include/getid3.php");
		if(write_tag($target_file, trim($_POST["title"]), trim($_POST["artist"]))) {
			echo json_encode(array("msg"=>"บันทึกข้อมูล ID3v2 เรียบร้อยแล้ว","result"=>"ok"));exit();
		} else {echo json_encode(array("msg"=>"ไม่สามารถบันทึก ID3v2 tag ได้","result"=>"error"));exit();}
	exit(); endif;
	if($_GET["id"]=="delete") :
		if($_POST["filename"]==""){echo json_encode(array("msg"=>"กรุณาเลือกเพลง","result"=>"error"));exit(); }
		$target_file = $CONFIG->Setting["system"]["path_music"].$_POST["filename"];
		if(!file_exists($target_file)) {echo json_encode(array("msg"=>"ไม่พบไฟล์เพลงนี้ในระบบ","result"=>"error"));exit(); }
		if(unlink($target_file)) {
			echo json_encode(array("msg"=>"ลบเพลงนี้เรียบร้อยแล้ว","result"=>"ok"));exit();
		} else {echo json_encode(array("msg"=>"ไม่สามารถลบได้","result"=>"error"));exit();}

	exit(); endif;
break;

case "control" : 
	$Control = new iSong_Control();
	if($_POST["ajax"]=="weblet") :
		if($_POST["type"]=="shoutcast") {
			$Class = new iSong_SHOUTcast();
			$text = array("restart"=>"ทำการเริ่มต้น SHOUTcast ใหม่เรียบร้อยแล้ว","kicksrc"=>"ตัดการเชื่อมต่อปัจจุบันเรียบร้อยแล้ว","reload"=>"Reload การตั้งค่าใหม่เรียบร้อยแล้ว");
			if($Class->weblet($_POST["action"])) { echo json_encode(array("msg"=>$text[$_POST["action"]],"result"=>"ok"));exit(); }
			else { echo json_encode(array("msg"=>"ไม่สามารถดำเนินรายการนี้ได้","result"=>"error"));exit();}
		}
		if($_POST["type"]=="transcoder") {
			$Class = new iSong_Transcoder();
			$text = array("restart"=>"ทำการเริ่มต้น Transcoder ใหม่เรียบร้อยแล้ว","nextsong"=>"ทำรายการเล่นเพลงต่อไป","loadplaylist"=>"Reload playlist");
			if($Class->weblet($_POST["action"])) { echo json_encode(array("msg"=>$text[$_POST["action"]],"result"=>"ok"));exit(); }
			else { echo json_encode(array("msg"=>"ไม่สามารถดำเนินรายการนี้ได้","result"=>"error"));exit();}
		}
	exit(); endif;
	if($_POST["ajax"]=="toggle") :
		if($_POST["type"]==""){echo json_encode(array("msg"=>"Toggle not found","result"=>"false"));exit(); }
		switch($_POST["type"]) {
			case "shoutcast" : 
			if($Control->Control_SHOUTcast()){
				sleep(1); if($Control->CheckProcess("shoutcast")){ $msg="SHOUTcast ได้ถูก <strong>เปิด</strong> เรียบร้อยแล้ว"; } else { $msg="SHOUTcast ได้ถูก <strong>ปิด</strong> เรียบร้อยแล้ว"; } 
				echo json_encode(array("msg"=>$msg,"result"=>"true")); exit();
			} else { echo json_encode(array("msg"=>"ไม่สามารถเริ่มการทำงานได้","result"=>"false")); exit(); }
			break;
			case "transcoder" : 
			if($Control->Control_Transcoder()){
				sleep(1); if($Control->CheckProcess("transcoder")){ $msg="Transcoder ได้ถูก <strong>เปิด</strong> เรียบร้อยแล้ว"; } else { $msg="Transcoder ได้ถูก <strong>ปิด</strong> เรียบร้อยแล้ว"; } 
				echo json_encode(array("msg"=>$msg,"result"=>"true")); exit();
			} else { echo json_encode(array("msg"=>"ไม่สามารถเริ่มการทำงานได้","result"=>"false")); exit(); }
			break;
		}
		
	exit(); endif;
	if($_POST["ajax"]=="status") :
		if($Control->CheckProcess("shoutcast")){
			$CheckProcess['shoutcast']="online";
			$SHOUTcast = new iSong_SHOUTcast();
			$sc_stats = $SHOUTcast->sc_stats();
$shoutcast_stats = '
<div class="well">
<h4 style="margin-top:2px;">Server Information <small>ข้อมูลเซิฟเวอร์</small> <div class="pull-right font10"><a class="btn btn-xs btn-primary" onclick="iniStatus();"><i class="fa fa-refresh"></i> Refresh</a>  <a onClick="toggleShow(\'table-shoutcast\');" class="cursor-pointer">Show/Hide</a></div></h4>
<div id="table-shoutcast">
<table class="table-shoutcast table table-striped">
    <tr>
        <th class="th1">SHOUTCast PID:</th><td class="td1">'.$Control->pidProccess("shoutcast").' (Mem: <strong>'.$Control->mem("shoutcast").'</strong>)</td>
    </tr>
    <tr>
        <th class="th1">Transcoder PID:</th><td class="td1">'.$Control->pidProccess("transcoder").' (Mem: <strong>'.$Control->mem("transcoder").'</strong>)</td>
    </tr>
    <tr>
        <th class="th1">Stream Status:</th><td class="td1">Listeners '.number_format($sc_stats["currentlisteners"]).' of '.number_format($sc_stats["maxlisteners"]).' ('.$sc_stats["uniquelisteners"].' unique)</td>
    </tr>
    <tr>
        <th class="th1">Paek Listens:</th><td class="td1">'.number_format($sc_stats["peaklisteners"]).'</td>
    </tr>
    <tr>
        <th class="th1">Max Listens:</th><td class="td1">'.number_format($sc_stats["maxlisteners"]).'</td>
    </tr>
    <tr>
        <th class="th1">Average Listen Time:</th><td class="td1">'.$sc_stats["averagetime"].'</td>
    </tr>
    <tr>
        <th class="th1">Server URL:</th><td class="td1">'.$sc_stats["serverurl"].'</td>
    </tr>
    <tr>
        <th class="th1">Stream Name:</th><td class="td1">'.$sc_stats["servertitle"].'</td>
    </tr>
    <tr>
        <th class="th1">Steam Path:</th><td class="td1">'.$sc_stats["streampath"].'</td>
    </tr>
    <tr>
        <th class="th1">Current Song:</th><td class="td1">'.$sc_stats["songtitle"].'</td>
    </tr>
    <tr>
        <th class="th1">Next Song:</th><td class="td1">'.$sc_stats["nexttitle"].'</td>
    </tr>
    <tr>
        <th class="th1">Content Type:</th><td class="td1">'.$sc_stats["bitrate"].' kbps - '.$sc_stats["content"].'</td>
    </tr>
    <tr>
        <th class="th1">Server Version:</th><td class="td1">SHOTCast Server v'.$sc_stats["version"].'</td>
    </tr>
</table>
</div>
</div>
';
		} else { $CheckProcess['shoutcast']="offline"; }
		if($Control->CheckProcess("transcoder")){
			$CheckProcess['transcoder']="online";
		} else { $CheckProcess['transcoder']="offline"; }
		
		$json = array("shoutcast_stats"=>$shoutcast_stats, "shoutcast_currentlisteners"=>number_format($sc_stats["currentlisteners"]),
		 "pid"=>array("shoutcast"=>$Control->pidProccess("shoutcast"),"transcoder"=>$Control->pidProccess("transcoder")), "status"=>array("shoutcast"=>$CheckProcess['shoutcast'], "transcoder"=>$CheckProcess['transcoder']));
		echo json_encode($json);
	exit(); endif;
break;

case "logs" :
	if($_GET["id"]=="delete") :
		if($_POST["filename"]=="") {echo json_encode(array("result"=>"File not found.","filename"=>"Unknow")); exit(); }
		$root_path = $CONFIG->Setting["system"]["path_backend"]."logs/";
		$file_path = $root_path.$_POST["filename"].".log";
		@unlink($file_path);
		echo json_encode(array("result"=>"ok")); exit();
	exit(); endif;
	if($_GET["id"]=="view") :
		if($_POST["filename"]=="") {echo json_encode(array("result"=>"File not found.","filename"=>"Unknow")); exit(); }
		$root_path = $CONFIG->Setting["system"]["path_backend"]."logs/";
		$file_path = $root_path.$_POST["filename"].".log";
		$content = file_get_contents($file_path);
		$content = str_replace("\r\n","\n",$content);
		echo json_encode(array("result"=>$content,"filename"=>$_POST["filename"].".log")); exit();
	exit(); endif;
break;

case "station" :

	if($_GET["id"]=="deleteallcomments") :
		$STATION = new iSong_Station();
		if($STATION->deleteAllComments()) {
			PageMSG("ลบความคิดเห็นทั้งหมดเรียบร้อยแล้ว",true,"dashboard.php?page=station");
		}
	exit(); endif;

	if($_GET["id"]=="deletecomment") :
		$STATION = new iSong_Station();
		if($STATION->deleteComment($_POST["comment"])) {
			echo json_encode(array("result"=>"ok","msg"=>"ลบความคิดเห็นเรียบร้อยแล้ว")); exit();
		}
	exit(); endif;

	if($_GET["id"]=="player") :
		if($_POST["do"]=="save") {
			$CONFIG->ConfigUpdate("station","cover",trim($_POST["cover"]));
			echo json_encode(array("result"=>"true")); exit();
		}
		if($_POST["do"]=="generated") {
			$CONFIG->ConfigUpdate("station","cover",trim($_POST["cover"]));
			$STATION = new iSong_Station();
			$Array = array(
				"theme"=>$_POST["theme"],
				"font"=>$_POST["font"],
				"color"=>$_POST["color"],
				"refresh"=>$_POST["refresh"],
				"substr"=>$_POST["substr"],
				"cover"=>$_POST["cover"]
			);
			$PlayerID = $STATION->GeneratedPlayer($Array);
			echo json_encode(array("player_id"=>$PlayerID));
		}
	
	exit(); endif;
	
break;

case "system" :
	if($_POST["site_title"]=="") { PageMSG("กรุณากรอก Site Title ",false,"dashboard.php?page=system"); exit(); }
	if($_POST["site_baseurl"]=="") { PageMSG("กรุณากรอก Baseurl ",false,"dashboard.php?page=system"); exit(); }
	if($_POST["station_title"]=="") { PageMSG("กรุณากรอก Station Title ",false,"dashboard.php?page=system"); exit(); }
	if($_POST["station_cover"]=="") { PageMSG("กรุณากรอก Cover ",false,"dashboard.php?page=system"); exit(); }
	if($_POST["system_path_root"]=="") { PageMSG("กรุณากรอก Path root ",false,"dashboard.php?page=system"); exit(); }
	if($_POST["system_ip"]=="") { PageMSG("กรุณากรอก ServerIP ",false,"dashboard.php?page=system"); exit(); }
	if(!filter_var($_POST["system_ip"], FILTER_VALIDATE_IP)) { PageMSG("ServerIP รูปแบบไม่ถูกต้อง ",false,"dashboard.php?page=system"); exit(); } 
	if(!filter_var($_POST["site_baseurl"], FILTER_VALIDATE_URL)) { PageMSG("Baseurl รูปแบบไม่ถูกต้อง ",false,"dashboard.php?page=system"); exit(); } 
	if(!is_dir($_POST["system_path_root"])) { PageMSG("ไม่พบ '".$path."' นี้ในระบบ ",false,"dashboard.php?page=system"); exit();  }
	
	/* System Array */
	$path = trim($_POST["system_path_root"]);
	$baseurl = trim($_POST["site_baseurl"]);
	$systemArray = array(
		"path_root"=>str_replace("//","/",$path),
		"path_backend"=>str_replace("//","/",$path."/backend/"),
		"path_music"=>str_replace("//","/",$path."/backend/music/"),
		"path_music_url"=>$baseurl."/backend/music/",
		"path_libs"=>str_replace("//","/",$path."/libs/"),
		"path_config"=>str_replace("//","/",$path."/libs/configuration/"),
		"path_win"=>str_replace("//","/",$path."/libs/win/"),
		"path_linux"=>str_replace("//","/",$path."/libs/linux/"),
		"path_pstools"=>str_replace("//","/",$path."/libs/win/pstools/"),
		"config_shoutcast"=>str_replace("//","/",$path."/libs/configuration/sc_isong.conf"),
		"config_transcoder"=>str_replace("//","/",$path."/libs/configuration/tr_isong.conf"),
		"ip"=>$_POST["system_ip"],
	);
	$CONFIG->ConfigUpdateArray("system",$systemArray);
	/* Site Array */
	$siteArray = array("title"=>($_POST["site_title"]), "baseurl"=>($_POST["site_baseurl"]));
	$CONFIG->ConfigUpdateMuti("site",$siteArray);
	//$CONFIG->ConfigUpdate("site","title",($_POST["site_title"]));
	//$CONFIG->ConfigUpdate("site","baseurl",($_POST["site_baseurl"]));
	/* Station Array */
	$stationArray = array("title"=>($_POST["station_title"]), "cover"=>($_POST["station_cover"]));
	$CONFIG->ConfigUpdateMuti("station",$stationArray);
	//$CONFIG->ConfigUpdate("station","title",($_POST["station_title"]));
	//$CONFIG->ConfigUpdate("station","cover",($_POST["station_cover"]));
	PageMSG("บันทึกการตั้งค่าพื้นฐานเรียบร้อยแล้ว, กรุณารอสักครู่",true,"dashboard.php?page=system"); exit();
	
	exit();
break;

default:  break;
}
?>