<?php $ISONG=true; require("include/config.php"); require_once("include/auth.php"); ?>
<?
/************************************************************************************
RadioStation - Control Panel | v.1.0 | Worrawat Watakit (CODESTUDIO Network Enterprises) 
RadioStation Control Panel © 2017 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
if($_SESSION["installed"]=="true") {
	@rename("install.php","install.old.php");
	$_SESSION["installed"]="";
} else {
	if($CONFIG->Setting("site","installed")=="false") {
	if(file_exists("install.php")) {
		header("Location: install.php");
	}
	}
}

require("pages/isong.dashboard.php");
$dashboardArray = array(
	"home"=>array("title"=>"ภาพรวมระบบ","desc"=>"System Information","icon"=>"home"),
	"system"=>array("title"=>"ตั้งค่าข้อมูลพื้นฐาน","desc"=>"System Configuration","icon"=>"edit"),
	"control"=>array("title"=>"ควบคุมระบบ","desc"=>"Control","icon"=>"cog"),
	"configuration"=>array("title"=>"ตั้งค่าระบบ","desc"=>"Configuration","icon"=>"cogs"),
	"music"=>array("title"=>"จัดการเพลง","desc"=>"Music","icon"=>"music"),
	"station"=>array("title"=>"ส่วนของสถานี","desc"=>"Station","icon"=>"play-circle"),
	"logs"=>array("title"=>"Logs","desc"=>"Logs","icon"=>"list-ul"),
);
$Control = new iSong_Control();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?=$dashboardArray[$_GET["page"]]['title']?> - <?=$CONFIG->Setting("site","title")?></title>
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link href="dist/css/bootstrap.css" rel="stylesheet">
<link href="dist/css/style.css" rel="stylesheet">
<link href="dist/css/jquery-ui.css" rel="stylesheet">
<script src="dist/js/jquery.js"></script>
<script src="dist/js/jquery-ui.js"></script>
<script src="dist/js/bootstrap.js"></script>
<script src="dist/js/bootstrap/button.js"></script>
<script src="dist/js/bootstrap/modal.js"></script>
<script src="dist/js/bootstrap/tab.js"></script>
<script src="dist/js/isong.js"></script>
<script src="dist/js/jquery.jgrowl.js"></script>
<link href="dist/css/jquery.jgrowl.css" rel="stylesheet">
</head>

<body>
<div id="wrap">
<? $header=$_GET["page"]; include("pages/template.header.php"); ?>
<div class="container">
    <div class="page-header fontsupermarket">
    	<h1><i class="fa fa-dashboard"></i> Dashboard <small>ส่วนจัดการ</small>
            <div class="pull-right pull-isong">
<?php /*?>            	<div class="pull-left pull-status">SHOUTcast: <a class="btn btn-xs btn-<? echo($Control->CheckProcess("shoutcast")) ? "success":"danger"; ?>"><? echo($Control->CheckProcess("shoutcast")) ? "Online":"Offline"; ?></a> AutoDJ: <a class="btn btn-xs btn-<? echo($Control->CheckProcess("transcoder")) ? "success":"danger"; ?>"><? echo($Control->CheckProcess("shoutcast")) ? "Online":"Offline"; ?></a></div>
<?php */?>                <div class="pull-right pull-os">OS: <strong><?=strtoupper(getOS())?></strong></div>
            </div>
        </h1>
    </div>
    
    <div class="row">
    	<div class="col-lg-4">
            <div class="list-group fontsupermarket">
<? foreach($dashboardArray as $item=>$list) { ?>
              <a href="?page=<?=$item?>" class="list-group-item<? if($item==$_GET["page"]){echo' active';}?>"><div class="list-group-item-heading"><i class="fa fa-<?=$list['icon']?>"></i> <?=$list['title']?></div> <p class="list-group-item-text font16"><?=$list['desc']?></p></a>
<? } ?>
            </div>        
        </div>
        <div class="col-lg-8 PanelMain">
        	<h3 class="page-header-sub fontsupermarket font24"><i class="fa fa-<?=$dashboardArray[$_GET["page"]]['icon']?>"></i> <?=$dashboardArray[$_GET["page"]]['title']?> <small><?=$dashboardArray[$_GET["page"]]['desc']?></small></h3>
<?
$incName = "pages/isong.".$_GET["page"].".php";
	if(file_exists($incName)) {
		include($incName);
	} else { header("Location: dashboard.php?page=home"); }
?>
        </div>
    </div>
    
    
</div>
</div><!-- #wrap -->
<? include("pages/template.footer.php"); ?>
</body>
</html>