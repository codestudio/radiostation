<?
/************************************************************************************
RadioStation - Control Panel | v.1.0 | Worrawat Watakit (CODESTUDIO Network Enterprises) 
RadioStation Control Panel © 2017 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
?>
<?php $ISONG=true; require("include/config.php"); ?>
<? /************************ STARTUP *************************/ 
if($_GET["theme"]) {
	if($_GET["theme"]==""){$theme="standard";}else{$theme=$_GET["theme"];}
	if($_GET["font"]=="supermarket"){$font="supermarket";$fontsize="16px";}else{$font="";$fontsize="14px";}
	if($_GET["color"]==""){$color="#000";}else{$color="#".$_GET["color"];}
	if($_GET["substr"]==""){$substr="40"; $_SESSION["substr"]=40;}else{$substr=$_GET["substr"];$_SESSION["substr"]=$_GET["substr"];}
	if($_GET["refresh"]==""){$refreshtime="30000";}else{$refreshtime=($_GET["refresh"]*1000);}
} else {
	if(isset($_GET["id"])) { 
		if(!isset($_GET["id"])) {die("Access denied!");} 
		$STATION = new iSong_Station(); 
		$Setting = $STATION->loadSetting($_GET["id"]);
		if(!$Setting) { die("Configuration ".$_GET["id"]." not found."); }
		$theme = $Setting['theme']; $color = "#".$Setting['color']; $substr=$Setting['substr']; $refreshtime=($Setting['refresh']*1000);
		if($Setting['font']=="supermarket"){$font="supermarket";$fontsize="16px";}else{$font="";$fontsize="14px";}
	}
}
if(!isset($_GET["section"])) {
		$SHOUTCAST = new iSong_SHOUTcast();
		$Stats = $SHOUTCAST->sc_stats();
		$iTunes = $SHOUTCAST->iTunes($Stats['songtitle']);
		if($substr=="") {$substr=$_SESSION["substr"];}
		if(!$iTunes){
			$Songtitle_ = iconv_substr($Stats['songtitle'], 0,$substr, "UTF-8");
			$Station = array(
				"cover"=>$CONFIG->Setting("station","cover"),
				"songtitle"=>$Songtitle_,
				"fullsongtitle"=>$Stats['songtitle'],
				"servertitle"=>$Stats['servertitle'],
				"nextsong"=>iconv_substr($Stats['nexttitle'], 0,$substr, "UTF-8"),
				"fullnextsong"=>$Stats['nexttitle'],
				"currentlisteners"=>$Stats['currentlisteners'],
			);
		} else {
			$Songtitle_ = iconv_substr($iTunes['artistName']." - ".$iTunes['trackName'], 0,$substr, "UTF-8");
			$Station = array(
				"cover"=>$iTunes['artworkUrl100'],
				"songtitle"=>$Songtitle_,
				"fullsongtitle"=>$iTunes['artistName']." - ".$iTunes['trackName'],
				"servertitle"=>$Stats['servertitle'],
				"nextsong"=>iconv_substr($Stats['nexttitle'], 0,$substr, "UTF-8"),
				"fullnextsong"=>$Stats['nexttitle'],
				"currentlisteners"=>$Stats['currentlisteners'],
			);
		}
}
if($_GET["section"]=="comment_ajax") :
	if($_POST["name"]=="") { echo json_encode(array("msg"=>"กรุณากรอกชื่อผู้ส่ง")); exit(); }
	if($_POST["comment"]=="") { echo json_encode(array("msg"=>"กรุณากรอกความคิดเห็น")); exit(); } 
		$fusComment = time()-$_SESSION["comment_time"];
		if($fusComment<=30) { echo json_encode(array("msg"=>"คุณเพึ่งได้แสดงความคิดเห็นไปเมื่อสักครู่แล้ว, กรุณาสักครู่")); exit();  } 
		$STATION = new iSong_Station();
		if($STATION->Comment(trim($_POST["name"]),trim($_POST["comment"]))) {
			echo json_encode(array("result"=>"true","msg"=>"บันทึกความคิดเห็นของคุณเรียบร้อยแล้ว")); exit(); 
		}
exit(); endif;
if($_GET["ajax"]=="status") :
	echo json_encode($Station);
exit(); endif;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?=$CONFIG->Setting("station","title")?> - iSong Control Panel</title>
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link href="dist/css/bootstrap.css" rel="stylesheet">
<link href="dist/css/style.css" rel="stylesheet">
<link href="dist/css/jquery-ui.css" rel="stylesheet">
<script src="dist/js/jquery.js"></script>
<script src="dist/js/jquery-ui.js"></script>
<script src="dist/js/bootstrap.js"></script>
<style>
body { font-family:<?=$font?>; font-size:<?=$fontsize?>;  background:none; padding:0px; margin:0px; }
.standard {
	margin:0 auto;
	width:99%;
	border:#CCC 1px solid;
	-webkit-border-radius: 7px;
	-moz-border-radius: 7px;
	border-radius: 7px;
	height:150px;
}
.full {
	height:200px;
}
.full .form { text-align:center; }
.full .form-control { display:inline; }
.full .btn { padding-top:3px; padding-bottom:3px; }
.standard .title {
	padding-left:10px;
	line-height:30px;
	height:30px;
	color:#fff;
	-webkit-border-top-left-radius: 7px;-webkit-border-top-right-radius: 7px;-moz-border-radius-topleft: 7px;-moz-border-radius-topright: 7px;border-top-left-radius: 7px;border-top-right-radius: 7px;	
}
.standard .title .pull-right {
	line-height:25px;
	padding-right:10px;
}
.standard .player { margin-bottom:3px;}
.standard .content {
	margin:5px;
}
.standard .cover {
	float:left;
	width:70px;
	margin-right:6px;
}
.standard .cover img {
	width:70px;
	height:70px;
}
.standard .details {
	float:left;
	height:100px;
}
.standard span { font-size:12px; }
.standard .text i { font-size:12px; }
#currentlisteners { font-weight:bold; }
.alink { color:#FFF; font-size:10px; cursor:pointer; }
.alink:hover { color:#fff; }
.scroll {
position: relative;
height: 200px;
margin-top: 10px;
overflow: auto;
}
.comments {
	height:260px;
}
.comments .title {
	padding:5px;
	text-align:center;
	font-size:18px;
	font-family:supermarket;
	background:#666;
	color:#fff;
}
.comments .content {
	padding:10px;
}
.comments .text-input { margin-bottom:10px; font-size:17px; font-family:supermarket; }
.comments input { width:100%; font-family:"Helvetica Neue", Helvetica, Arial, sans-serif;}
.comments #footer {margin-top:20px;margin-bottom: 0px; }
.comments .content .alert { font-size:17px; font-family:supermarket; }
.mini {
	-webkit-border-radius: 25px;
	-moz-border-radius: 25px;
	border-radius: 25px;	
}
.mini .content {
	padding-bottom:6px;
	padding-top:6px;
	padding-left:15px;
	padding-right:15px;
}
.mini .title {
	font-size:16px;
	font-family:supermarket;
	color:#fff;
}
.mini .title small { font-size:12px; }
.circle {
}
.circle .cover .artwork {
	position: absolute;
	border-radius: 50px;
	overflow: hidden;
	border: 2px solid #fff;
	box-shadow: 0 0 5px rgba(0, 0, 0, 0.41);
	background-color: #eee;
	text-align: center;
	width: 65px;
	height: 65px;
	top:3px;
	left:3px;
}
.circle .content {
	margin-top:10px;
	margin-left:30px;
	padding-top:5px;
	padding-left:43px;
	-webkit-border-radius: 20px;
	-moz-border-radius: 20px;
	border-radius: 20px;
	height:50px;
}
.circle .title { font-size:13px; color:#FFF; margin-right:15px; }
.circle i { font-size:10px; }
.cirecle .player { margin-top:3px; }
</style>
</head>

<body>
<? /************************ COMMENTS ************************ */ ?>
<? if($_GET["section"]=="comments") : ?>
<style>body{background:#f2f2f2;}</style>
<div class="comments">
	<div class="title"><i class="fa fa-comments"></i> แสดงความคิดเห็นถึง <?=$CONFIG->Setting("station","title")?></div>
    <div class="content">
<? if(isset($_POST["comment"])) { 
	if($_POST["name"]=="") { echo'<div class="alert alert-danger"><i class="fa fa-warning"> กรุณากรอกชื่อผู้ส่ง</i> </div>';} else {
	if($_POST["comment"]=="") { echo'<div class="alert alert-danger"><i class="fa fa-warning"> กรุณากรอกข้อความ</i> </div>';} else {
		$fusComment = time()-$_SESSION["comment_time"];
		if($fusComment<=30) { echo'<div class="alert alert-danger"><i class="fa fa-warning"> คุณได้เพึ่งแสดงความคิดเห็นไปแล้ว</i> </div>';  } else {
		$STATION = new iSong_Station();
		if($STATION->Comment(trim($_POST["name"]),trim($_POST["comment"]))) {
?>
    <div class="alert alert-success"><i class="fa fa-check-circle"></i> ทำการส่งความคิดเห็นเรียบร้อยแล้ว</div>
        <div class="text-input" style="margin-top:20px;"><a href="?section=comments" target="_self" class="btn btn-black btn-block btn-lg"><i class="fa fa-backward"></i> ย้อนกลับ</a></div>
<? 
		} // end fusComment
		} // end true
} // End name
} // End comment ?>
<? } else { ?>
    <form action="station.php?section=comments" method="post" target="_self">
    	<div class="text-input">ชื่อผู้ส่ง: <input type="text" class="form-control" name="name" placeholder="ชื่อผู้ส่ง" required></div>
        <div class="text-input">ข้อความ: <input type="text" class="form-control" name="comment" placeholder="ข้อความ" required></div>
        <div class="text-input" style="margin-top:20px;"><button type="submit" class="btn btn-black btn-block btn-lg"><i class="fa fa-comment"></i> แสดงความคิดเห็น</button></div>
    </form>
<? } ?>
        <? $footerShort=true; include("pages/template.footer.php"); ?>
    </div>
</div>


<? endif; ?>
<? /************************ THEME ************************ */ ?>
<? switch($theme) { ?>
<? case "standard" : ?>
<div class="standard">
	<div class="title" style="background-color:<?=$color?>;"><?=$CONFIG->Setting("station","title")?> <div class="pull-right"><a class="alink" onClick="Comments();"><i class="fa fa-comment"></i> Comment</a> </div> </div>
    <div class="content">
    	<div class="player"><embed src="dist/player.swf" width="100%" height="20" allowscriptaccess="always" wmode="transparent" flashvars="file=http://<?=$CONFIG->Setting("system","ip")?>:<?=$CONFIG->Configuration("shoutcast","portbase")?>/stream.nsv&amp;type=mp3&amp;stretch=none&amp;autostart=true&amp;volume=100&amp;displayclick=none&amp;frontcolor=<?=$color?>"></embed></div>
    	<div class="cover"><img src="<?=$Station['cover']?>" id="img-cover" class="img-rounded"></div>
        <div class="details">
        	<div class="text"><i class="fa fa-music"></i> <span id="songtitle" title="<?=$Station['fullsongtitle']?>"><?=iconv_substr($Station['songtitle'], 0,$substr, "UTF-8");?></span></div>
            <div class="text"><i class="fa fa-headphones"></i> <span id="servertitle"><?=$Station['servertitle']?></span></div>
            <div class="text"><i class="fa fa-user"></i> <span id="currentlisteners"><?=$Station['currentlisteners']?></span> ผู้ฟัง</div>
        </div>
    </div>
</div>
<? break; // End case Standard ?>
<? case "html5" : ?>
<div class="standard">
	<div class="title" style="background-color:<?=$color?>;"><?=$CONFIG->Setting("station","title")?> <div class="pull-right"><a class="alink" onClick="Comments();"><i class="fa fa-comment"></i> Comment</a> </div> </div>
    <div class="content">
    	<div class="player">
            <audio id="player" controls autoplay="yes" style="width:99%;">
                 <source src="http://<?=$CONFIG->Setting("system","ip")?>:<?=$CONFIG->Configuration("shoutcast","portbase")?>/stream.ogg" type="audio/ogg" />
                 <source src="http://<?=$CONFIG->Setting("system","ip")?>:<?=$CONFIG->Configuration("shoutcast","portbase")?>/stream.mpeg" type="audio/mpeg" />
            </audio> 
        </div>
    	<div class="cover"><img src="<?=$Station['cover']?>" id="img-cover" class="img-rounded"></div>
        <div class="details">
        	<div class="text"><i class="fa fa-music"></i> <span id="songtitle" title="<?=$Station['fullsongtitle']?>"><?=iconv_substr($Station['songtitle'], 0,$substr, "UTF-8");?></span></div>
            <div class="text"><i class="fa fa-headphones"></i> <span id="servertitle"><?=$Station['servertitle']?></span></div>
            <div class="text"><i class="fa fa-user"></i> <span id="currentlisteners"><?=$Station['currentlisteners']?></span> ผู้ฟัง</div>
        </div>
    </div>
</div>
<? break; // End case HTML5 ?>
<? case "full" : ?>
<div class="standard full">
	<div class="title" style="background-color:<?=$color?>;"><?=$CONFIG->Setting("station","title")?> <div class="pull-right"><a class="alink" onClick="Comments();"><i class="fa fa-comment"></i> Comment</a> </div> </div>
    <div class="content">
    	<div class="player"><embed src="dist/player.swf" width="100%" height="20" allowscriptaccess="always" wmode="transparent" flashvars="file=http://<?=$CONFIG->Setting("system","ip")?>:<?=$CONFIG->Configuration("shoutcast","portbase")?>/stream.nsv&amp;type=mp3&amp;stretch=none&amp;autostart=true&amp;volume=100&amp;displayclick=none&amp;frontcolor=<?=$color?>"></embed></div>
    	<div class="cover" style="width:90px; height:90px;"><img src="<?=$Station['cover']?>" id="img-cover" class="img-rounded" style="width:90px; height:90px;"></div>
        <div class="details">
        	<div class="text"><i class="fa fa-music"></i> <span id="songtitle" title="<?=$Station['fullsongtitle']?>"><?=iconv_substr($Station['songtitle'], 0,$substr, "UTF-8");?></span></div>
        	<div class="text"><i class="fa fa-fast-forward"></i> <span id="nextsong" title="<?=$Station['fullnextsong']?>"><?=iconv_substr($Station['nextsong'], 0,$substr, "UTF-8");?></span></div>
            <div class="text"><i class="fa fa-headphones"></i>  <span id="servertitle"><?=$Station['servertitle']?></span></div>
            <div class="text"><i class="fa fa-user"></i> <span id="currentlisteners"><?=$Station['currentlisteners']?></span> ผู้ฟัง</div>
        </div>
        <div class="clearfix"></div>
        <div class="form">
            <form onSubmit="stationComment();" action="javascript:;">
                <div class="text-input"><input type="text" class="form-control input-sm" id="c_name" placeholder="ชื่อผู้ส่ง" required> 
                <input type="text" class="form-control input-sm" id="c_comment" placeholder="ข้อความ" required>
                <button type="submit" class="btn btn-black"><i class="fa fa-comment"></i> ส่ง</button></div>
            </form>
        </div>
    </div>
</div>
<script>
function stationComment() {
	var name = $("#c_name").val(), comment = $("#c_comment").val();
	$.post("<?=$_SERVER['PHP_SELF']?>?section=comment_ajax",{name:name,comment:comment},function(data){
		alert(data['msg']);
		if(data['result']=='true') { $("#c_name").val(""); $("#c_comment").val(""); }
	},"json");
}
</script>
<? break; // End case Full ?>
<? case "mini" : ?>
<div class="mini" style="background-color:<?=$color?>;">
    <div class="content" >
        <div class="title"><?=$CONFIG->Setting("station","title")?> <div class="pull-right"><a class="alink" onClick="Comments();"><i class="fa fa-comment"></i> Comment</a> </div> </div>
    	<div class="player"><embed src="dist/player.swf" width="100%" height="20" allowscriptaccess="always" wmode="transparent" flashvars="file=http://<?=$CONFIG->Setting("system","ip")?>:<?=$CONFIG->Configuration("shoutcast","portbase")?>/stream.nsv&amp;type=mp3&amp;stretch=none&amp;autostart=true&amp;volume=100&amp;displayclick=none&amp;frontcolor=<?=$color?>"></embed>
</div>
    </div>
</div>
<? break; // End case Circle ?>
<strong><? case "circle" : ?>
<div class="circle" >
    <div class="cover"><img src="<?=$Station['cover']?>" id="img-cover" class="artwork"></div>
    <div class="content" style="background-color:<?=$color?>;">
        <div class="title"><i class="fa fa-music"></i> <span id="songtitle" title="<?=$Station['fullsongtitle']?>"><?=iconv_substr($Station['songtitle'], 0,$substr, "UTF-8");?></span>
         <div class="pull-right"><a class="alink" onClick="Comments();" style="background-color:<?=$color?>;"><i class="fa fa-comment"></i> Comment</a> </div> </div>
    	<div class="player"><embed src="dist/player.swf" width="95%" height="20" allowscriptaccess="always" wmode="transparent" flashvars="file=http://<?=$CONFIG->Setting("system","ip")?>:<?=$CONFIG->Configuration("shoutcast","portbase")?>/stream.nsv&amp;type=mp3&amp;stretch=none&amp;autostart=true&amp;volume=100&amp;displayclick=none&amp;frontcolor=<?=$color?>"></embed>
</div>
    </div>
</div>
<? break; // End case Circle ?>
</strong>
<? } // Switch $_GET["theme"] ?>
<? if(isset($theme)) { ?>
<script>
$(document).ready(function(e) {
	setTimeout(function(){ iSongStation(); },<?=$refreshtime?>);
});
function Comments() {
	var url = "station.php?section=comments";
	newwindow=window.open(url,'popupWindow','height=280,width=280,location=no,scrollbars=no,toolbar=no');
	if (window.focus) {newwindow.focus()}
}
function iSongStation() {
	$.get("station.php",{"ajax":"status"},function(data){
		$("#songtitle").html(data['songtitle']).attr("title",data['fullsongtitle']);
		$("#servertitle").html(data['servertitle']);
		$("#currentlisteners").html(data['currentlisteners']);
		$("#nextsong").html(data['nextsong']).attr("title",data['fullnextsong']);
		$("#img-cover").attr("src",data['cover']);
		setTimeout(function(){ iSongStation(); },<?=$refreshtime?>);
	},"json");
}
</script>
<? } ?>
</body>
</html>