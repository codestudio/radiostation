<?php $ISONG=true; require("include/config.php"); ?>
<?
/************************************************************************************
iSong - Control Panel | v.1.0 | Worrawat Watakit (CodeZa) 
iSong Control Panel © 2014 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
$licence = "localhost";
$stepArray = array(
	"1"=>array("title"=>"Step 1","desc"=>"ตรวจสอบระบบ","icon"=>"cog"),
	"2"=>array("title"=>"Step 2","desc"=>"สิทธิ์การเขียนไฟล์","icon"=>"cog"),
	"3"=>array("title"=>"Step 3","desc"=>"ตั้งค่าพื้นฐาน","icon"=>"cog"),
	"4"=>array("title"=>"Completed","desc"=>"เสร็จสิ้นการติดตั้ง","icon"=>"check"),
);
if($_GET["step"]==""){header("Location: install.php?step=1"); } else {
	$step = $_GET["step"];
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Install ติดตั้งระบบ iSong Control Panel</title>
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link href="dist/css/bootstrap.css" rel="stylesheet">
<link href="dist/css/style.css" rel="stylesheet">
<link href="dist/css/jquery-ui.css" rel="stylesheet">
<script src="dist/js/jquery.js"></script>
<script src="dist/js/jquery-ui.js"></script>
<script src="dist/js/bootstrap.js"></script>
<script src="dist/js/bootstrap/button.js"></script>
<script src="dist/js/isong.js"></script>
<script src="dist/js/jquery.jgrowl.js"></script>
<link href="dist/css/jquery.jgrowl.css" rel="stylesheet">
<style>
.enabled { color:#090; }
.disabled { color:#F00; }
.btn-next { font-family:supermarket; font-size:22px; }
</style>
</head>

<body>
<div id="wrap">
    <div class="navbar navbar-inverse navbar-fixed-top fontsupermarket" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand font20" href="/home/"><?=$CONFIG->Setting("site","short_title")?></a>
        </div>
        <ul class="nav navbar-nav font16">
          <li<? if($step=="1")echo' class="active"';?>><a > Step 1</a></li>
          <li<? if($step=="2")echo' class="active"';?>><a > Step 2</a></li>
          <li<? if($step=="3")echo' class="active"';?>><a > Step 3</a></li>
          <li<? if($step=="4")echo' class="active"';?>><a > Completed</a></li>

        </ul>
      </div>
    </div>

<div class="container">
    <div class="page-header fontsupermarket">
    	<h1><i class="fa fa-cogs"></i> Install <small>ติดตั้ง iSong Control Panel</small></h1>
    </div>
    
    <div class="row">
    	<div class="col-lg-4">
            <div class="list-group fontsupermarket">
<? foreach($stepArray as $item=>$list) { ?>
              <a class="list-group-item<? if($item==$_GET["step"]){echo' active';}?>"><div class="list-group-item-heading"><i class="fa fa-<?=$list['icon']?>"></i> <?=$list['title']?></div> <p class="list-group-item-text font16"><?=$list['desc']?></p></a>
<? } ?>
            </div>        
        </div>
        <div class="col-lg-8 PanelMain">
        <? if($CONFIG->Setting("site","installed")=="true"){echo'<div class="alert alert-danger">คุณได้เคยติดตั้งไปแล้ว, กรุณาเปลี่ยนชื่อ install.php นี้หรือลบออกจากระบบ, <a href="index.php">คลิกที่นี้</a> เพื่อไปยังหน้าแรก</div>';}?>
        	<h3 class="page-header-sub fontsupermarket font24"><i class="fa fa-<?=$stepArray[$step]['icon']?>"></i> <?=$stepArray[$step]['title']?> <small><?=$stepArray[$step]['desc']?></small></h3>
<? switch($step) { ?>
<? /****************** STEP 1 ******************/ case "1": ?>
<? 
$enabled = '<span class="enabled"><i class="fa fa-check"></i> Enabled</span>';
$disabled = '<span class="disabled"><i class="fa fa-times"></i> Disabled</span>';
$debug = true; $_SESSION["stepCurrent"] = $step."_false";
function parseInisize($str){
	$cutof = strtolower(substr($str,-1));
	
	if(!is_numeric($cutof)){
		$num = substr($str,0,-1);
		if($cutof == "m")
		{
			return (int)$num * 1024;
		}
		if($cutof == "g")
		{
			return (int)$num * 1024 * 1024;
		}
	}
	return $str;
}

?>
<div class="text-center"><img src="dist/images/sc-logo.jpg"><hr></div>
    <dl class="dl-horizontal">
      <dt>Operation System</dt><dd><? echo(getOS()=="win")?"Windows":"Linux";?></dd>
      <dt>Licence iSong CP</dt><dd><?=$licence?></dd>
      <dt>PHP Version</dt><dd><? if (version_compare(PHP_VERSION, '5.0.0', '<')) { $debug=false; ?> <span  class="disabled"><i class="fa fa-times"></i> PHP older version. Require 5.0.0+</span> <? } else {echo '<span class="enabled"><i class="fa fa-check"></i> '.phpversion().'</span>'; }?></dd>
      <dt>PHP EXEC</dt><dd><? if(function_exists('exec')) { echo $enabled; }else{ echo $disabled; $debug=false; } ?></dd>
      <dt>PHP FILES</dt><dd><? if(function_exists('file_put_contents')) { echo $enabled; }else{ echo $disabled; $debug=false; } ?></dd>
      <dt>PHP CURL</dt><dd><? if(function_exists('curl_init')) { echo $enabled; }else{ echo $disabled; $debug=false; }?></dd>
      <dt>Upload max size</dt><dd><? if(parseInisize(ini_get('upload_max_filesize'))>"10240") { echo '<span class="enabled"><i class="fa fa-check"></i> '.ini_get('upload_max_filesize').'</span>'; }else{ $debug=false; ?><span class="disabled">More than 10M</span><? } ?></dd>
      <dt>Post max size</dt><dd><? if(parseInisize(ini_get('post_max_size'))>"10240") { echo '<span class="enabled"><i class="fa fa-check"></i> '.ini_get('post_max_size').'</span>'; }else{ $debug=false; ?><span class="disabled">More than 10M</span><? } ?></dd>
    </dl>
    <div id="section-debug">
    <? if(!$debug) { ?><div class="alert alert-danger"><i class="fa fa-warning"></i> ไม่สามารถดำเนินการต่อได้, กรุณาตรวจสอบความต้องการของระบบ และทำการเริ่มการติดตั้งใหม่อีกครั้ง</div><? } else { ?>
    	<a class="btn btn-primary btn-lg btn-block btn-next" href="<?=$_SERVER['PHP_SELF']?>?step=2"><?=$stepArray[2]['title']?> <small>: <?=$stepArray[2]['desc']?></small> <i class="fa fa-arrow-right"></i></a>
    <? $_SESSION["stepCurrent"] = $step."_true"; } ?>
    </div>
<? break; //step 1 ?>
<? /****************** STEP 2 ******************/ case "2": ?>
<? 
$enabled = '<span class="enabled"><i class="fa fa-check"></i> Allow</span>';
$disabled = '<span class="disabled"><i class="fa fa-times"></i> Permission denied</span>';
$debug = true; $_SESSION["stepCurrent"] = $step."_false";
$path_parts = pathinfo($_SERVER["SCRIPT_FILENAME"]);
$root_path = str_replace('/install.php', '', $path_parts['dirname'])."/";
$files = array(
	"config"=>array("name"=>"Configuration","path"=>$root_path."include/config.xml"),
	"backend_folder"=>array("name"=>"Backend Folder","path"=>$root_path."backend/"),
	"backend_logs"=>array("name"=>"Logs folder","path"=>$root_path."backend/logs/"),
	"backend_music"=>array("name"=>"Music folder","path"=>$root_path."backend/music/"),
	"backend_station"=>array("name"=>"Station folder","path"=>$root_path."backend/station/"),
	"backend_station_style"=>array("name"=>"Style folder","path"=>$root_path."backend/station/style/"),
	"backend_file_playlist"=>array("name"=>"Backend Playlist.lst","path"=>$root_path."backend/playlist.lst"),
	"backend_file_comments"=>array("name"=>"Backend comments.xml","path"=>$root_path."backend/station/comments.xml"),
	"backend_file_scpid"=>array("name"=>"Backend SHOUTcast PID","path"=>$root_path."backend/shoutcast.pid"),
	"backend_file_trpid"=>array("name"=>"Backend Transcoder PID","path"=>$root_path."backend/transcoder.pid"),
	"libs_config_sc"=>array("name"=>"SHOUTcast Configuration","path"=>$root_path."libs/configuration/sc_isong.conf"),
	"libs_config_tr"=>array("name"=>"Transcoders Configuration","path"=>$root_path."libs/configuration/tr_isong.conf"),
);
$server = array(
	"win"=>array(
		"shoutcast"=>array("name"=>"SHOUTcast ","path"=>$root_path."libs/win/sc_serv.exe"),
		"transcoder"=>array("name"=>"Transcoder","path"=>$root_path."libs/win/sc_trans.exe"),
	),
	"linux"=>array(
		"shoutcast"=>array("name"=>"SHOUTcast ","path"=>$root_path."libs/linux/sc_serv"),
		"transcoder"=>array("name"=>"Transcoder","path"=>$root_path."libs/linux/sc_trans"),
	)
);
?>
    <dl class="dl-horizontal">
    <? foreach($files as $key=>$value) { ?>
      <dt><?=$value['name']?></dt> <dd><div style="font-size:11px;"><?=$value['path']?></div><? if (is_writable($value['path'])) {echo $enabled;}else{echo $disabled; $debug=false; }?></dd>
    <? } ?>
      <dt>SHOUTcast</dt> <dd><div style="font-size:11px;"><?=$server[getOS()]['shoutcast']['path']?></div><? if (is_writable($server[getOS()]['shoutcast']['path'])) {echo $enabled;}else{echo $disabled; $debug=false; }?></dd>
      <dt>Transcoder</dt> <dd><div style="font-size:11px;"><?=$server[getOS()]['transcoder']['path']?></div><? if (is_writable($server[getOS()]['transcoder']['path'])) {echo $enabled;}else{echo $disabled; $debug=false; }?></dd>
    </dl>
    <? if(!$debug){?>
    	<div class="text-center"><a class="btn btn-primary" href="<?=$_SERVER['PHP_SELF']?>?step=2"><i class="fa fa-refresh"></i> Refresh</a></div>
    <div class="alert alert-warning"><i class="fa fa-info-circle"></i> ควรตั้ง Permission ของไฟล์ข้างต้นเป็น 0777 เพื่อให้การแก้ไขสิทธิไฟล์การตั้งค่าๆ ได้, 
    <ul>
    	<li>SHOUTcast และ Transcoder เป็นสิ่งจำเป็นที่จะต้องกำหนดสิทธิ์เป็นอนุญาตเมิน</li>
        <li>โฟลเดอร์ /backend ครวจะทำทุกไฟล์ในโฟลเดอณ์ดังกล่าว</li>
    </ul>
    </div><? }?>
    <div id="section-debug">
    <? if(!$debug) { ?><div class="alert alert-danger"><i class="fa fa-warning"></i> ไม่สามารถดำเนินการต่อได้, กรุณาตรวจสอบความต้องการของระบบ และทำการเริ่มการติดตั้งใหม่อีกครั้ง</div><? } else { ?>
    	<a class="btn btn-primary btn-lg btn-block btn-next" href="<?=$_SERVER['PHP_SELF']?>?step=3"><?=$stepArray[3]['title']?> <small>: <?=$stepArray[3]['desc']?></small> <i class="fa fa-arrow-right"></i></a>
    <? $_SESSION["stepCurrent"] = $step."_true"; } ?>
    </div>
<style> dd {margin-bottom:3px; }</style>
<? break; ?>

<? /****************** STEP 3 ******************/ case "3": ?>
<?	if($_SESSION["stepCurrent"]!="2_true") {header("Location: install.php?step=1");}
function full_url($s)
{
    $ssl = (!empty($s['HTTPS']) && $s['HTTPS'] == 'on') ? true:false;
    $sp = strtolower($s['SERVER_PROTOCOL']);
    $protocol = substr($sp, 0, strpos($sp, '/')) . (($ssl) ? 's' : '');
    $port = $s['SERVER_PORT'];
    $port = ((!$ssl && $port=='80') || ($ssl && $port=='443')) ? '' : ':'.$port;
    $host = isset($s['HTTP_X_FORWARDED_HOST']) ? $s['HTTP_X_FORWARDED_HOST'] : isset($s['HTTP_HOST']) ? $s['HTTP_HOST'] : $s['SERVER_NAME'];
	$url = $protocol . '://' . $host . $port . $s['REQUEST_URI'];
	$explode = explode("install.php",$url);
    return $explode[0];
}
$path_parts = pathinfo($_SERVER["SCRIPT_FILENAME"]);
$root_path = str_replace('/install.php', '', $path_parts['dirname'])."/";
?>
<form class="form-horizontal form-panel" id="form" role="form" action="<?=$_SERVER['PHP_SELF']?>?step=4" method="post">
  <div class="form-group">
    <label for="password" class="col-sm-3 control-label">CP Password</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="password" placeholder="Password" name="password" required>
    </div>
  </div>
  <div class="form-group">
    <label for="site_title" class="col-sm-3 control-label">Site Title</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="site_title" name="site_title" value="<?=$CONFIG->Setting("site","title")?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="site_baseurl" class="col-sm-3 control-label">Baseurl</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="site_baseurl" name="site_baseurl" value="<?=full_url($_SERVER)?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="station_title" class="col-sm-3 control-label">Station title</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="station_title" name="station_title" value="<?=$CONFIG->Setting("station","title")?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="station_cover" class="col-sm-3 control-label">Station Cover</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="station_cover" name="station_cover" value="<?=$CONFIG->Setting("station","cover")?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="system_path_root" class="col-sm-3 control-label">Base directory</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-10" id="system_path_root" name="system_path_root" value="<?=$root_path?>" required>
    </div>
  </div>
  <div class="form-group">
    <label for="system_ip" class="col-sm-3 control-label">ServerIP</label>
    <div class="col-sm-9">
      <input type="text" class="form-control col-lg-4" id="system_ip" name="system_ip" value="<?=$_SERVER['SERVER_ADDR'];?>" required>
    </div>
  </div>
      <button type="submit" class="btn btn-primary btn-lg btn-block btn-next"><i class="fa fa-arrow-right"></i> <?=$stepArray[3]['title']?> <small>: <?=$stepArray[3]['desc']?></small></button>
</form>
<? $_SESSION["stepCurrent"] = $step."_true"; break; //step 2 ?>
<? /****************** STEP 4******************/ case "4": ?>
<?
if($_SESSION["stepCurrent"]!="3_true") {header("Location: install.php?step=1");}
	$debugMsg = array(); $debug=true;
	if($_POST["password"]=="") { $debugMsg[] = "กรุณากรอก Password"; $debug=false; }
	if($_POST["site_title"]=="") { $debugMsg[] = "กรุณากรอก Site Title"; $debug=false; }
	if($_POST["site_baseurl"]=="") { $debugMsg[] = "กรุณากรอก Baseurl"; $debug=false; }
	if($_POST["station_title"]=="") { $debugMsg[] = "กรุณากรอก Station Title"; $debug=false; }
	if($_POST["station_cover"]=="") { $debugMsg[] = "กรุณากรอก Station Cover"; $debug=false; }
	if($_POST["system_path_root"]=="") { $debugMsg[] = "กรุณากรอก Base directory"; $debug=false; }
	if($_POST["system_ip"]=="") { $debugMsg[] = "กรุณากรอก Server IP"; $debug=false; }
	if(!filter_var($_POST["system_ip"], FILTER_VALIDATE_IP)) { $debugMsg[] = "รูปแบบของ IP ไม่ถูกต้อง"; $debug=false; } 
	if(!filter_var($_POST["site_baseurl"], FILTER_VALIDATE_URL)) { $debugMsg[] = "รูปแบบของ Baseurl ไม่ถูกต้อง"; $debug=false; } 
	if(!is_dir($_POST["system_path_root"])) { $debugMsg[] = "ไม่พบ '".$_POST["system_path_root"]."' นี้ในระบบของคุณ"; $debug=false;  }

	if(!$debug) {
		echo '<div class="alert alert-danger"><i class="fa fa-warning"></i> ไม่สามารถดำเนินการต่อได้, เนื่องจากพบข้อผิดผลาดดังนี้ <ul>';	
		foreach($debugMsg as $msg) { echo'<li>'.$msg.'</li>'; }
		echo '</ul></div>';
	} else {
	/* System Array */
	$path = trim($_POST["system_path_root"]);
	$baseurl = trim($_POST["site_baseurl"]);
	$systemArray = array(
		"path_root"=>str_replace("//","/",$path),
		"path_backend"=>str_replace("//","/",$path."/backend/"),
		"path_music"=>str_replace("//","/",$path."/backend/music/"),
		"path_music_url"=>$baseurl."/backend/music/",
		"path_libs"=>str_replace("//","/",$path."/libs/"),
		"path_config"=>str_replace("//","/",$path."/libs/configuration/"),
		"path_win"=>str_replace("//","/",$path."/libs/win/"),
		"path_linux"=>str_replace("//","/",$path."/libs/linux/"),
		"path_pstools"=>str_replace("//","/",$path."/libs/win/pstools/"),
		"config_shoutcast"=>str_replace("//","/",$path."/libs/configuration/sc_isong.conf"),
		"config_transcoder"=>str_replace("//","/",$path."/libs/configuration/tr_isong.conf"),
		"ip"=>$_POST["system_ip"],
	);
	$CONFIG->ConfigUpdateArray("system",$systemArray);
	$siteArray = array("installed"=>"true","title"=>($_POST["site_title"]), "baseurl"=>($_POST["site_baseurl"]));
	$CONFIG->ConfigUpdateMuti("site",$siteArray);
	$stationArray = array("title"=>($_POST["station_title"]), "cover"=>($_POST["station_cover"]));
	$CONFIG->ConfigUpdateMuti("station",$stationArray);
	$Auth = new iSong_Auth();
	$Auth->SavePassword($_POST["password"]);
	$ConfigGenerated = new iSong_Configuration(); 
	$ConfigGenerated->Transcoder();
	$ConfigGenerated->Shoutcast();
	$_SESSION["installed"] = "true";
	sleep(1);

?>
    <div class="text-center"><img src="dist/images/sc-logo.jpg"><hr></div>
	<div class="alert alert-success"><i class="fa fa-check"></i> การติดตั้ง iSong Control Panel เสร็จสมบูรณ์, กรุณาเปลี่ยนชื่อไฟล์หรือลบไฟล์ install.php นี้ออกจากระบบ</div>
    <a class="btn btn-primary btn-lg btn-block btn-next" href="index.php">iSong Control Panel</a>
    <? } ?>
<? break; ?>
<? } // End Switch ?>

        </div>
    </div>
    
</div>
</div><!-- #wrap -->
<? include("pages/template.footer.php"); ?>
</body>
</html>