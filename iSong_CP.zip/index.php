<?php $RadioStation=true; require("include/config.php"); ?>
<?php
/************************************************************************************
RadioStation - Control Panel | v.1.0 | Worrawat Watakit (CODESTUDIO Network Enterprises) 
RadioStation Control Panel © 2017 Copy All rights reserved.
Contact: Tel.085-520-6997 , Email: codestudio@live.com 
************************************************************************************/
if($_SESSION["installed"]=="true") {
	@rename("install.php","install.old.php");
	$_SESSION["installed"]="";
} else {
	if($CONFIG->Setting("site","installed")=="false") {
	if(file_exists("install.php")) {
		header("Location: install.php");
	}
	}
}
if($_GET["do"]=="save") :
	
	if(isset($_POST["password"])) {
		if($_POST["password"]==$_POST["repassword"]) {
			$Auth = new RadioStation_Auth();
			if($Auth->SavePassword($_POST["password"])) {
				$_SESSION["msg_ok"]="เปลี่ยนรหัสผ่านใหม่เรียบร้อยแล้ว";
				PageMSG("เปลี่ยนรหัสผ่านเรียบร้อยแล้ว",true,"dashboard.php?page=account");
			} else {
				PageMSG("ไม่สามารถเปลี่ยนรหัสผ่านได้, กรุณาลองใหม่อีกครั้ง",false);
			}
		} else {
			PageMSG("Password ทั้งสองไม่ตรงกัน.",false);
		}
	} else {
		PageMSG("Password Incorrect.",false);	
	}
die("ERROR: 100"); endif;
if($_GET["do"]=="logout") :
	$Auth = new RadioStation_Auth();
	$Auth->doLogout(); header("Location: index.php");
die("ERROR: 100"); endif;
if($_POST["password"]) :
	if(isset($_POST["password"])) {
		$Signin = new RadioStation_Auth();
		if($Signin->Signin($_POST["password"])) {
			if($_GET["return"]){$return = $_GET["return"];}else{$return="dashboard.php";}
			PageMSG("เข้าสู่ระบบ RadioStation Control Panel เรียบร้อยแล้ว, กรุณารอสักครู่",true,$return);
		} else {
			PageMSG("รหัสผ่านไม่ถูกต้อง",false);
		}
	}
die("ERROR: 100"); endif;

$Auth = new RadioStation_Auth();
if($Auth->isAuth()) {
	header("Location: dashboard.php");
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo$CONFIG->Setting("site","title")?></title>
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link href="dist/css/bootstrap.css" rel="stylesheet">
<link href="dist/css/style.css" rel="stylesheet">
<script src="dist/js/jquery.js"></script>
<script src="dist/js/jquery-ui.js"></script>
<script src="dist/js/bootstrap.js"></script>
<style>
body {
  padding-bottom: 40px;
  background-color: #eee;
}
.container { max-width:330px; margin-bottom:20px; }
.form-signin {
  max-width:90%;
  padding: 15px;
  margin: 0 auto;
}
.form-signin .form-signin-heading,
.form-signin .checkbox {
  margin-bottom: 10px;
}
.form-signin .checkbox {
  font-weight: normal;
}
.form-signin .form-control {
  position: relative;
  font-size: 16px;
  height: auto;
  padding: 10px;
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="text"] {
  margin-bottom: -1px;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
</head>

<body>

<div class="page-header text-center"><h1><i class="fa fa-music"></i> RadioStation Control Panel </h1></div>

    <div class="container MainContent">

      <form action="<?php echo $_SERVER['PHP_SELF'];?>?return=<?php echo $_GET["return"];?>" method="post" class="form-signin" role="form">
        <h2 class="form-signin-heading">Please sign in</h2>
        <input name="password" type="password" class="form-control col-lg-12" placeholder="Password" required autofocus>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
      </form>

    </div> <!-- /container -->
<div class="text-center">Copyright &copy; <?php echo date('Y');?> <strong>RadioStation Control Panel</strong></div>
</body>
</html>